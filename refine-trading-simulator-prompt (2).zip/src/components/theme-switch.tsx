"use client";

import { useSyncExternalStore } from "react";
import { THEME_COLORS, THEME_KEY, type Theme } from "@/lib/appearance";
import { Icon } from "./icons";

function applyTheme(theme: Theme) {
  document.documentElement.dataset.theme = theme;
  const meta = document.querySelector<HTMLMetaElement>('meta[name="theme-color"]');
  if (meta) meta.content = THEME_COLORS[theme];
}
function readTheme(): Theme { return document.documentElement.dataset.theme === "light" ? "light" : "dark"; }
function subscribe(notify: () => void) {
  const onStorage = (event: StorageEvent) => {
    if (event.key !== THEME_KEY && event.key !== null) return;
    applyTheme(event.newValue === "light" ? "light" : "dark");
    notify();
  };
  window.addEventListener("storage", onStorage);
  window.addEventListener("papertrade:appearance", notify);
  return () => { window.removeEventListener("storage", onStorage); window.removeEventListener("papertrade:appearance", notify); };
}
const defaultTheme = (): Theme => "dark";

export function ThemeSwitch() {
  const theme = useSyncExternalStore(subscribe, readTheme, defaultTheme);
  const choose = (value: Theme) => {
    applyTheme(value);
    try { localStorage.setItem(THEME_KEY, value); } catch { /* The selection still works for the current tab. */ }
    window.dispatchEvent(new Event("papertrade:appearance"));
  };
  return <div className="appearance-switch" role="group" aria-label="Color theme">
    {(["light", "dark"] as const).map(value => <button key={value} type="button" aria-pressed={theme === value} aria-label={`Use ${value} mode`} title={`Use ${value} mode`} data-theme-option={value} onClick={() => choose(value)}>
      <Icon name={value === "light" ? "sun" : "moon"} size={15}/><span>{value === "light" ? "Light" : "Dark"}</span>
    </button>)}
  </div>;
}
