// Host the exported files only. All trading and appearance logic stays in the browser.
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..', 'out');
const port = Number(process.env.PORT || 3000);
const types = { '.html':'text/html; charset=utf-8', '.js':'text/javascript', '.css':'text/css', '.json':'application/json', '.svg':'image/svg+xml', '.png':'image/png', '.jpg':'image/jpeg', '.ico':'image/x-icon', '.txt':'text/plain; charset=utf-8', '.woff2':'font/woff2', '.webmanifest':'application/manifest+json' };

function resolveFile(requestUrl) {
  const clean = decodeURIComponent(new URL(requestUrl, 'http://localhost').pathname);
  if (clean.includes('\0')) return null;
  // Resolve path components, without changing legitimate dots inside a chunk filename.
  const requested = path.resolve(root, `.${clean}`);
  if (requested !== root && !requested.startsWith(root + path.sep)) return null;
  for (const file of [requested, requested + '.html', path.join(requested,'index.html'), path.join(requested,'index.json')]) {
    if (file !== root && file.startsWith(root + path.sep) && fs.statSync(file, {throwIfNoEntry:false})?.isFile()) return file;
  }
  return null;
}
http.createServer((req, res) => {
  if (req.method !== 'GET' && req.method !== 'HEAD') { res.writeHead(405, {allow:'GET, HEAD'}); return res.end(); }
  let file;
  try { file = resolveFile(req.url || '/'); } catch { res.writeHead(400); return res.end('Bad request'); }
  const status = file ? 200 : 404;
  if (!file) file = path.join(root,'404.html');
  if (!fs.existsSync(file)) { res.writeHead(404); return res.end('Not found'); }
  res.writeHead(status, { 'content-type':types[path.extname(file)] || 'application/octet-stream', 'cache-control':file.includes('/_next/static/') ? 'public, max-age=31536000, immutable' : 'no-cache' });
  if (req.method === 'HEAD') return res.end();
  fs.createReadStream(file).on('error', () => res.destroy()).pipe(res);
}).listen(port, () => console.log(`Serving static PaperTrade workspace on port ${port}`));
