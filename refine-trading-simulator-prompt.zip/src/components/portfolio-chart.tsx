"use client";

import { useMemo, useState } from "react";
import { FanChart, type FanBand, LineChart } from "@/components/charts";
import { Pill, Segmented } from "@/components/ui";
import { useSim } from "@/components/providers";
import { fmtCompact, fmtMoney, fmtSignedMoney, fmtSignedPct } from "@/lib/format";
import { fmtDayShort } from "@/lib/time";
import { loadPortfolioProjection } from "@/lib/client/research";

type PortfolioProjection = {
  bands: FanBand[];
  runCount: number;
  startValue: number;
  horizonDays: number;
  latestHistoryDate: string;
  dataSymbols: string[];
  cashWeight: number;
  sourceType: string;
  method: string;
};

const PROJECTION_HORIZONS = [
  { days: 252, label: "1 year" },
  { days: 756, label: "3 years" },
  { days: 1260, label: "5 years" },
];

function futureLabel(day: number) {
  if (day === 0) return "Today";
  if (day < 21) return `${day}d`;
  if (day < 252) return `${Math.round(day / 21)}m`;
  return `${(day / 252).toFixed(day % 252 === 0 ? 0 : 1)}y`;
}

export function PortfolioChart() {
  const { snapshot } = useSim();
  const [range, setRange] = useState(63);
  const [mode, setMode] = useState<"history" | "future">("history");
  const [horizonDays, setHorizonDays] = useState(252);
  const [projection, setProjection] = useState<PortfolioProjection | null>(null);
  const [projectionKey, setProjectionKey] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  const investments = useMemo(() => (snapshot?.holdings ?? [])
    .filter(h => h.value > 0 && (snapshot?.totals.portfolioValue ?? 0) > 0)
    .map(h => ({ symbol: h.symbol, weight: h.value / (snapshot?.totals.portfolioValue ?? 1) })), [snapshot?.holdings, snapshot?.totals.portfolioValue]);
  if (!snapshot) return null;
  const { totals, equityCurve, market } = snapshot;
  const data = range ? equityCurve.filter(p => p.day >= market.day - range) : equityCurve;
  const curve = data.length ? data : equityCurve.slice(-1);
  const moneyParts = fmtMoney(totals.portfolioValue).split(".");
  const selected = PROJECTION_HORIZONS.find(h => h.days === horizonDays) ?? PROJECTION_HORIZONS[0];
  const currentKey = `${totals.portfolioValue.toFixed(2)}:${investments.map(p => `${p.symbol}-${p.weight.toFixed(5)}`).join(",")}:${horizonDays}`;

  const loadProjection = async () => {
    if (busy) return;
    setMode("future");
    if (projection && projectionKey === currentKey) return;
    if (!investments.length) {
      setError("Add at least one virtual stock holding to project portfolio growth.");
      return;
    }
    setBusy(true);
    setError("");
    try {
      const result = await loadPortfolioProjection({ startValue: totals.portfolioValue, horizonDays, positions: investments });
      setProjection(result as unknown as PortfolioProjection);
      setProjectionKey(currentKey);
    } catch (e) {
      setProjection(null);
      setProjectionKey("");
      setError(e instanceof Error ? e.message : "Couldn’t calculate the portfolio projection.");
    } finally {
      setBusy(false);
    }
  };

  const updateHorizon = (days: number) => {
    setHorizonDays(days);
    setProjection(null);
    setProjectionKey("");
    setError("");
  };

  return <section className="panel flex flex-col overflow-hidden">
    <div className="flex flex-wrap items-start justify-between gap-4 px-6 pt-6">
      <div>
        <p className="card-label">{mode === "history" ? "Total portfolio value" : "Possible future portfolio value"}</p>
        <p className="portfolio-amount tnum mt-3">{moneyParts[0]}<span className="text-[#acb6ac]">.{moneyParts[1]}</span></p>
        {mode === "history" ? <div className="mt-3 flex flex-wrap items-center gap-2"><Pill tone={totals.totalPnl >= 0 ? "up" : "down"}>{fmtSignedPct(totals.totalPnlPct)}</Pill><span className="text-[11px] text-[#8c9a89]"><span className={totals.totalPnl >= 0 ? "up" : "down"}>{fmtSignedMoney(totals.totalPnl)}</span> all time</span></div> : <p className="hint mt-3">Starting value for your {selected.label} portfolio projection.</p>}
      </div>
      <div className="flex flex-wrap items-center gap-2">
        <span className="pill !bg-[#fafbf7] !text-[9px]">Virtual USD</span>
        <Segmented options={[{ value: "history", label: "Past" }, { value: "future", label: "Future growth" }]} value={mode} onChange={next => { setMode(next); setError(""); }}/>
      </div>
    </div>

    {mode === "history" ? <>
      <div className="mt-7 flex-1 px-6 pb-3">
        <LineChart series={[{ name: "Practice portfolio", values: curve.map(p => p.value), color: "#739a58", fill: true, width: 2.2 }]} labels={curve.map(p => fmtDayShort(p.day, market.epoch))} height={210} formatValue={fmtCompact} formatTooltip={fmtMoney}/>
      </div>
      <div className="mt-3 flex flex-wrap items-center justify-between gap-3 border-t border-[var(--line)] px-6 py-4"><span className="flex items-center gap-2 text-[10px] text-[#99a38f]"><span className="h-1.5 w-1.5 rounded-full bg-[#8db273]"/> Cash + investments · simulated practice prices</span><Segmented options={[{ value: 5, label: "1W" }, { value: 21, label: "1M" }, { value: 63, label: "3M" }, { value: 0, label: "All" }]} value={range} onChange={setRange}/></div>
    </> : <>
      <div className="mt-6 flex flex-wrap items-center justify-between gap-3 px-6">
        <span className="hint">Different possible outcomes. Not a promised return.</span>
        <Segmented options={PROJECTION_HORIZONS.map(h => ({ value: h.days, label: h.label }))} value={horizonDays} onChange={updateHorizon}/>
      </div>
      <div className="min-h-[225px] px-6 pt-5 pb-2">
        {busy ? <div className="flex h-[220px] flex-col items-center justify-center gap-3 text-center"><span className="h-6 w-6 animate-spin rounded-full border-2 border-[#dbe7d2] border-t-[#739a58]"/><p className="text-xs font-medium">Learning from your stocks’ real history…</p><p className="hint">Looking up the latest daily closes for {investments.map(p => p.symbol).join(", ")}.</p></div> : projection && projectionKey === currentKey ? <FanChart bands={projection.bands} labels={projection.bands.map(b => futureLabel(b.day))} startValue={projection.startValue} height={220} formatValue={fmtCompact}/> : <div className="flex h-[220px] flex-col items-center justify-center gap-3 text-center"><p className="text-sm font-medium">See a range of possible outcomes.</p><p className="hint max-w-sm">Uses daily price history for your holdings, from {projection?.latestHistoryDate || "the latest data available"}. Cash is kept flat.</p><button type="button" disabled={busy || !investments.length} className="btn btn-primary" onClick={() => void loadProjection()}>{investments.length ? "Build my future growth graph" : "Buy a practice stock first"}</button></div>}
      </div>
      {projection && projectionKey === currentKey && <div className="mx-6 mb-4 grid grid-cols-3 gap-2 border-t border-[var(--line)] pt-4 sm:gap-3">{[{ label: "Lower range", value: projection.bands.at(-1)?.p5 }, { label: "Middle estimate", value: projection.bands.at(-1)?.p50 }, { label: "Upper range", value: projection.bands.at(-1)?.p95 }].map((item, index) => <div key={item.label}><p className="text-[10px] text-[var(--muted)]">{item.label}</p><p className={`tnum mt-1 text-sm font-medium sm:text-base ${index === 1 ? "text-[#54804c]" : ""}`}>{fmtMoney(item.value ?? totals.portfolioValue, 0)}</p></div>)}</div>}
      {error && <p className="mx-6 mb-4 rounded-lg border border-[#f1dfd7] bg-[#fff9f6] p-3 text-xs text-[#a86a59]" role="alert">{error}<button type="button" className="ml-2 underline" disabled={busy} onClick={() => void loadProjection()}>Try again</button></p>}
      <div className="border-t border-[var(--line)] px-6 py-4"><p className="text-[10px] text-[var(--muted)]">{projection && projectionKey === currentKey ? `${projection.runCount.toLocaleString()} simulated paths · Data through ${projection.latestHistoryDate} · ${projection.dataSymbols.join(", ")}` : "Projection based on actual historical daily prices, not your simulated practice history."}</p><p className="mt-1 text-[10px] text-[#9da697]">Yahoo Finance daily history may be delayed. Model estimates are uncertain, ignore future news and fees, and are not financial advice.</p></div>
    </>}
  </section>;
}
