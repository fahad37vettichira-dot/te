// Minimal static file server for the exported site (./out).
// No application logic lives here — it only serves files, exactly like any CDN would.
const http = require("node:http");
const fs = require("node:fs");
const path = require("node:path");

const root = path.resolve(__dirname, "..", "out");
const port = Number(process.env.PORT || 3000);
const types = { ".html": "text/html; charset=utf-8", ".js": "text/javascript", ".css": "text/css", ".json": "application/json", ".svg": "image/svg+xml", ".png": "image/png", ".jpg": "image/jpeg", ".ico": "image/x-icon", ".txt": "text/plain; charset=utf-8", ".woff2": "font/woff2", ".webmanifest": "application/manifest+json" };

function resolveFile(urlPath) {
  const clean = decodeURIComponent(urlPath.split("?")[0]).replace(/\.\./g, "");
  const candidates = [clean, clean.replace(/\/$/, "") + ".html", path.join(clean, "index.html"), path.join(clean, "index.json")];
  for (const c of candidates) {
    const full = path.join(root, c);
    if (full.startsWith(root) && fs.existsSync(full) && fs.statSync(full).isFile()) return full;
  }
  return null;
}

http.createServer((req, res) => {
  const file = resolveFile(req.url || "/");
  if (!file) {
    const notFound = path.join(root, "404.html");
    res.writeHead(404, { "content-type": "text/html; charset=utf-8" });
    return fs.existsSync(notFound) ? fs.createReadStream(notFound).pipe(res) : res.end("Not found");
  }
  res.writeHead(200, { "content-type": types[path.extname(file)] || "application/octet-stream", "cache-control": file.includes("/_next/static/") ? "public, max-age=31536000, immutable" : "no-cache" });
  fs.createReadStream(file).pipe(res);
}).listen(port, () => console.log(`Static site served from ${root} on http://127.0.0.1:${port}`));
