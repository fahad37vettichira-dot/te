"use client";

import { useId, useMemo, useState } from "react";
import type { OhlcPoint } from "@/lib/api-types";
import { fmtMoney } from "@/lib/format";

export type ChartSeries = { name: string; values: number[]; color: string; fill?: boolean; dashed?: boolean; width?: number };
const finiteValues = (values: number[]) => values.filter(Number.isFinite);
function linePath(points: [number, number][]) { return points.map(([x, y], i) => `${i ? "L" : "M"}${x.toFixed(2)},${y.toFixed(2)}`).join(" "); }

export function Sparkline({ values, width = 80, height = 29, tone, className = "" }: { values: number[]; width?: number; height?: number; tone?: "up" | "down"; className?: string }) {
  const id = useId().replace(/:/g, "");
  const data = finiteValues(values || []);
  if (data.length < 2) return <div style={{ width, height }} />;
  const lo = Math.min(...data), hi = Math.max(...data), span = hi - lo || 1;
  const points: [number, number][] = data.map((v, i) => [i / (data.length - 1) * 100, 5 + (1 - (v - lo) / span) * 90]);
  const color = tone === "up" || (!tone && data[data.length - 1] >= data[0]) ? "var(--up)" : "var(--down)";
  return <svg viewBox="0 0 100 100" preserveAspectRatio="none" width={width} height={height} className={className} aria-label="Recent simulated price trend" role="img"><defs><linearGradient id={id} x1="0" y1="0" x2="0" y2="1"><stop stopColor={color} stopOpacity=".13"/><stop offset="1" stopColor={color} stopOpacity="0"/></linearGradient></defs><path d={`${linePath(points)} L100,100 L0,100 Z`} fill={`url(#${id})`} /><path d={linePath(points)} fill="none" stroke={color} strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" vectorEffect="non-scaling-stroke"/></svg>;
}

export function LineChart({ series, labels, height = 240, formatValue = fmtMoney, formatTooltip, baseline, showYAxis = true, showGrid = true, showLastValue = false, xTicks = 5, min, max, className = "" }: { series: ChartSeries[]; labels: string[]; height?: number; formatValue?: (v: number) => string; formatTooltip?: (v: number) => string; baseline?: number; showYAxis?: boolean; showGrid?: boolean; showLastValue?: boolean; xTicks?: number; min?: number; max?: number; className?: string }) {
  const id = useId().replace(/:/g, "");
  const [hover, setHover] = useState<number | null>(null);
  const count = Math.max(...series.map(s => s.values.length), 0);
  const { low, high, ticks } = useMemo(() => {
    const values = finiteValues(series.flatMap(s => s.values));
    if (baseline !== undefined) values.push(baseline);
    const lo = min ?? Math.min(...values), hi = max ?? Math.max(...values);
    const span = hi - lo || Math.max(1, Math.abs(hi) * .05);
    const rough = span / 4, base = 10 ** Math.floor(Math.log10(rough));
    const step = ([1, 2, 2.5, 5, 10].find(n => n >= rough / base) || 10) * base;
    const low = Math.floor((lo - span * .03) / step) * step, high = Math.ceil((hi + span * .09) / step) * step;
    const ticks = Number.isFinite(low) ? Array.from({ length: Math.round((high-low)/step)+1 }, (_, i) => low + i*step) : [];
    return { low, high, ticks };
  }, [series, min, max, baseline]);
  if (!count || !Number.isFinite(low)) return <div className="chart-empty" style={{ height }}>Your chart will appear after your first trade.</div>;
  const x = (i: number) => count > 1 ? i / (count - 1) * 1000 : 500;
  const y = (v: number) => 9 + (1 - (v - low) / (high - low || 1)) * (height - 18);
  const active = hover === null ? null : Math.min(count - 1, Math.max(0, hover));
  const format = formatTooltip || formatValue;
  const last = series[0].values.at(-1);
  return <div className={`finance-chart ${className}`}><div className="chart-canvas-row">
    {showYAxis && <div className="chart-axis-y" style={{ height }}>{ticks.map(t => <span key={t} style={{ top: y(t) }}>{formatValue(t)}</span>)}</div>}
    <div className="chart-canvas" style={{ height }} tabIndex={0} role="img" aria-label={`${series.map(s => s.name).join(", ")} interactive chart. Use the arrow keys to inspect data.`}
      onKeyDown={e => { if (e.key === "ArrowLeft" || e.key === "ArrowRight") {e.preventDefault();setHover(Math.max(0,Math.min(count-1,(hover ?? count-1)+(e.key === "ArrowLeft" ? -1 : 1))));} if(e.key === "Escape") setHover(null); }}
      onPointerMove={e => { const box=e.currentTarget.getBoundingClientRect();setHover(Math.round(Math.max(0,Math.min(1,(e.clientX-box.left)/box.width))*(count-1))); }} onPointerLeave={() => setHover(null)} onBlur={() => setHover(null)}>
      <svg viewBox={`0 0 1000 ${height}`} preserveAspectRatio="none" className="chart-svg"><defs>{series.map((s, i) => <linearGradient key={`${s.name}-${i}`} id={`${id}-${i}`} x1="0" y1="0" x2="0" y2="1"><stop stopColor={s.color} stopOpacity=".27"/><stop offset=".65" stopColor={s.color} stopOpacity=".09"/><stop offset="1" stopColor={s.color} stopOpacity="0"/></linearGradient>)}</defs>
        {showGrid && ticks.map(t => <line key={t} x1="0" x2="1000" y1={y(t)} y2={y(t)} stroke="var(--plot-grid)" strokeDasharray="3 5" vectorEffect="non-scaling-stroke"/>)}
        {baseline !== undefined && <line x1="0" x2="1000" y1={y(baseline)} y2={y(baseline)} stroke="var(--benchmark)" strokeDasharray="5 5" opacity=".65" vectorEffect="non-scaling-stroke"/>}
        {series.map((s, idx) => { const d=linePath(s.values.map((v,i)=>[x(i),y(v)]));return <g key={`${s.name}-${idx}`}>{s.fill && <path d={`${d} L${x(s.values.length-1)},${height} L${x(0)},${height} Z`} fill={`url(#${id}-${idx})`}/>}<path d={d} fill="none" stroke={s.color} strokeWidth={s.width || 2} strokeDasharray={s.dashed ? "4 5" : undefined} strokeLinecap="round" strokeLinejoin="round" vectorEffect="non-scaling-stroke"/>{s.values.length===1 && <circle cx="500" cy={y(s.values[0])} r="3" fill={s.color}/>}</g>; })}
        {active !== null && <line x1={x(active)} x2={x(active)} y1="0" y2={height} stroke="var(--plot-cursor)" strokeDasharray="3 4" vectorEffect="non-scaling-stroke"/>}
      </svg>
      {showLastValue && active === null && last !== undefined && <span className="latest-point" style={{ top:y(last) }}><span>{format(last)}</span></span>}
      {active !== null && series.map((s,idx) => s.values[active] !== undefined && <i key={idx} className="chart-point" style={{left:`${x(active)/10}%`,top:y(s.values[active]),background:s.color}}/>)}
      {active !== null && <div className="chart-tooltip" style={{left:`${Math.max(1,Math.min(99,x(active)/10))}%`,transform:`translateX(${active > count*.5 ? "-100%" : "0"})`}}><span>{labels[active]}</span>{series.map((s,idx) => <div key={idx}><i style={{background:s.color}}/>{s.name}<strong>{s.values[active]!==undefined ? format(s.values[active]) : "—"}</strong></div>)}</div>}
    </div></div>
    <div className={`chart-axis-x ${showYAxis ? "with-y" : ""}`}>{Array.from({length:Math.min(xTicks,count)},(_,i) => {const idx=Math.round(i/Math.max(1,Math.min(xTicks,count)-1)*(count-1));return <span key={i}>{labels[idx]}</span>;})}</div>
  </div>;
}

export type FanBand = { day: number; p5: number; p25: number; p50: number; p75: number; p95: number; mean?: number };
export function FanChart({ bands, labels, startValue, height = 260, formatValue = fmtMoney }: { bands: FanBand[]; labels: string[]; startValue: number; samples?: number[][]; height?: number; formatValue?: (v: number) => string }) {
  const id = useId().replace(/:/g, "");
  const [hover, setHover] = useState<number | null>(null);
  if (!bands.length) return <div style={{ height }} />;
  const lo = Math.min(startValue, ...bands.map(b => b.p5)) * .95, hi = Math.max(startValue, ...bands.map(b => b.p95)) * 1.04;
  const x = (i: number) => i / Math.max(bands.length - 1, 1) * 1000;
  const y = (v: number) => 12 + (1 - (v - lo) / (hi - lo || 1)) * (height - 24);
  const polygon = (top: "p95" | "p75", bottom: "p5" | "p25") => [...bands.map((b, i) => `${x(i)},${y(b[top])}`), ...bands.slice().reverse().map((b, i) => `${x(bands.length - 1 - i)},${y(b[bottom])}`)].join(" ");
  const active = hover !== null ? bands[Math.min(hover, bands.length - 1)] : null;
  return <div><div className="relative" style={{ height }} onPointerMove={e => { const box = e.currentTarget.getBoundingClientRect(); setHover(Math.round(Math.min(1, Math.max(0, (e.clientX - box.left) / box.width)) * (bands.length - 1))); }} onPointerLeave={() => setHover(null)}><svg viewBox={`0 0 1000 ${height}`} preserveAspectRatio="none" className="h-full w-full"><defs><linearGradient id={id} x1="0" y1="0" x2="0" y2="1"><stop stopColor="var(--chart-a)" stopOpacity=".35"/><stop offset="1" stopColor="var(--up-soft)" stopOpacity=".2"/></linearGradient></defs>{[0, .5, 1].map(t => <line key={t} x1="0" x2="1000" y1={12 + (height - 24) * t} y2={12 + (height - 24) * t} stroke="var(--plot-grid)" strokeDasharray="3 5" vectorEffect="non-scaling-stroke"/>)}<polygon points={polygon("p95", "p5")} fill={`url(#${id})`} stroke="var(--chart-a)" strokeWidth="1" vectorEffect="non-scaling-stroke"/><polygon points={polygon("p75", "p25")} fill="var(--chart-a)" fillOpacity=".28"/><path d={linePath(bands.map((b, i) => [x(i), y(b.p50)]))} fill="none" stroke="var(--chart-a)" strokeWidth="2.2" vectorEffect="non-scaling-stroke"/><line x1="0" x2="1000" y1={y(startValue)} y2={y(startValue)} stroke="var(--benchmark)" strokeDasharray="5 5" vectorEffect="non-scaling-stroke"/></svg><span className="absolute top-0 right-0 text-[10px] text-[var(--muted)]">{formatValue(hi)}</span><span className="absolute right-0 bottom-0 text-[10px] text-[var(--muted)]">{formatValue(lo)}</span>{active && <div className="pointer-events-none absolute left-3 top-3 rounded-lg bg-[var(--tooltip)] px-3 py-2 text-[10px] text-white shadow-lg"><div className="mb-1 text-white/60">{labels[hover || 0]}</div><div>Higher outcome: {formatValue(active.p95)}</div><div className="my-1 font-semibold">Typical outcome: {formatValue(active.p50)}</div><div>Lower outcome: {formatValue(active.p5)}</div></div>}</div><div className="mt-3 flex justify-between text-[10px] text-[var(--muted)]"><span>{labels[0]}</span><span>{labels[Math.floor(labels.length / 2)]}</span><span>{labels.at(-1)}</span></div></div>;
}

export function Donut({ slices, size = 160, thickness = 17, centerLabel, centerValue }: { slices: Array<{ label: string; value: number; color: string }>; size?: number; thickness?: number; centerLabel?: string; centerValue?: string }) {
  const total = slices.reduce((a, s) => a + Math.max(0, s.value), 0), radius = (size - thickness) / 2, c = 2 * Math.PI * radius;
  let offset = 0;
  return <div className="relative shrink-0" style={{ width: size, height: size }}><svg width={size} height={size} className="-rotate-90" aria-label="Portfolio allocation" role="img"><circle cx={size / 2} cy={size / 2} r={radius} fill="none" stroke="var(--line)" strokeWidth={thickness}/>{total > 0 && slices.map(s => { const length = Math.max(0, s.value / total * c - 3); const off = offset; offset += Math.max(0, s.value / total) * c; return <circle key={s.label} cx={size / 2} cy={size / 2} r={radius} fill="none" stroke={s.color} strokeWidth={thickness} strokeDasharray={`${length} ${c - length}`} strokeDashoffset={-off}><title>{s.label}: {fmtMoney(s.value)}</title></circle>; })}</svg><div className="absolute inset-0 flex flex-col items-center justify-center"><span className="text-[10px] text-[var(--muted)]">{centerLabel || "Total"}</span><span className="tnum mt-1 text-lg font-medium tracking-tight">{centerValue || fmtMoney(total, 0)}</span></div></div>;
}

export function Meter({ value, tone = "accent", label, caption }: { value: number; tone?: "up" | "down" | "accent" | "warn"; label?: string; caption?: string }) {
  const colors = { up: "var(--up)", down: "var(--down)", accent: "var(--accent)", warn: "var(--warn)" };
  return <div className="min-w-0 flex-1">{(label || caption) && <div className="mb-2 flex justify-between gap-3 text-[10px]"><span className="text-[var(--muted)]">{label}</span><span className="tnum">{caption}</span></div>}<div className="h-1.5 rounded-full bg-[var(--raised)]"><div className="h-full rounded-full" style={{ width: `${Math.min(100, Math.max(0, value * 100))}%`, background: colors[tone] }}/></div></div>;
}

export function CandlestickChart({ bars, labels, height = 260, baseline }: { bars: OhlcPoint[]; labels: string[]; sma20?: Array<number | null>; sma50?: Array<number | null>; showSma?: boolean; showVolume?: boolean; baseline?: number; height?: number }) {
  const [hover, setHover] = useState<number | null>(null);
  if (!bars.length) return <div style={{ height }}/>;
  const lo = Math.min(...bars.map(b => b.low)), hi = Math.max(...bars.map(b => b.high)), pad = (hi - lo) * .1 || hi * .02;
  const y = (v: number) => 8 + (1 - (v - lo + pad) / (hi - lo + 2 * pad)) * (height - 20);
  const x = (i: number) => (i + .5) / bars.length * 1000;
  const w = Math.min(11, 650 / bars.length);
  const b = hover === null ? null : bars[hover];
  return <div><div className="relative" style={{ height }} onPointerMove={e => { const box = e.currentTarget.getBoundingClientRect(); setHover(Math.min(bars.length - 1, Math.max(0, Math.floor((e.clientX - box.left) / box.width * bars.length)))); }} onPointerLeave={() => setHover(null)}><svg viewBox={`0 0 1000 ${height}`} preserveAspectRatio="none" className="h-full w-full">{[0, .5, 1].map(t => <line key={t} x1="0" x2="1000" y1={8 + (height - 20) * t} y2={8 + (height - 20) * t} stroke="var(--plot-grid)" strokeDasharray="3 5" vectorEffect="non-scaling-stroke"/>)}{baseline !== undefined && <line x1="0" x2="1000" y1={y(baseline)} y2={y(baseline)} stroke="var(--benchmark)" strokeDasharray="5 5" vectorEffect="non-scaling-stroke"/>}{bars.map((bar, i) => { const color = bar.close >= bar.open ? "var(--up)" : "var(--down)"; return <g key={bar.day}><line x1={x(i)} x2={x(i)} y1={y(bar.high)} y2={y(bar.low)} stroke={color} strokeWidth="1" vectorEffect="non-scaling-stroke"/><rect x={x(i) - w / 2} y={Math.min(y(bar.open), y(bar.close))} width={w} height={Math.max(1.2, Math.abs(y(bar.close) - y(bar.open)))} fill={color} rx="1"/></g>; })}</svg>{b && <div className="pointer-events-none absolute top-2 left-2 rounded-lg bg-[var(--tooltip)] px-3 py-2 text-[10px] text-white"><div>{labels[hover!]}</div><div className="mt-1">Open {fmtMoney(b.open)} · High {fmtMoney(b.high)}</div><div>Low {fmtMoney(b.low)} · Close {fmtMoney(b.close)}</div></div>}</div><div className="mt-3 flex justify-between text-[10px] text-[var(--muted)]"><span>{labels[0]}</span><span>{labels.at(-1)}</span></div></div>;
}

export function Histogram({ buckets, height = 110, marker, formatValue = fmtMoney }: { buckets: Array<{ from: number; to: number; count: number }>; height?: number; marker?: number; color?: string; formatValue?: (v: number) => string }) { const max = Math.max(1, ...buckets.map(b => b.count)); return <div><div className="flex items-end gap-1" style={{ height }}>{buckets.map((b, i) => <div key={i} className="flex-1 rounded-t-sm" style={{ height: `${Math.max(1, b.count / max * 100)}%`, background: (b.to + b.from) / 2 < (marker ?? 0) ? "var(--down)" : "var(--up)" }} title={`${formatValue(b.from)}–${formatValue(b.to)}: ${b.count} outcomes`}/>)}</div><div className="mt-2 flex justify-between text-[10px] text-[var(--muted)]"><span>{formatValue(buckets[0]?.from || 0)}</span><span>{formatValue(buckets.at(-1)?.to || 0)}</span></div></div>; }
export function ScoreGauge({ score, title, subtitle, size = 160 }: { score: number; title: string; subtitle?: string; size?: number }) { return <div className="flex flex-col items-center justify-center gap-2" style={{ width: size }}><div className="text-2xl font-medium">{title}</div><Meter value={(score + 100) / 200}/><span className="hint">{subtitle}</span></div>; }
export function ProbabilityBadge({ value }: { value: number }) { return <span className="pill pill-up">{Math.round(value * 100)}%</span>; }
