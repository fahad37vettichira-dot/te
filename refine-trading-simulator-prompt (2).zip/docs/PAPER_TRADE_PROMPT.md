# Paper Trade — simple but capable build prompt

Build **Paper Trade**, a calm, beginner-friendly stock-market learning website. It should feel like an investing app, not a professional trading terminal. Users practise with virtual money; nothing connects to a real broker or payment service.

## Keep the main journey obvious
1. See my account value, available virtual cash, and profit or loss.
2. Find a company I recognize and look at its practice price or real daily history.
3. Enter an amount, review the order, and confirm a virtual buy or sell.
4. Check a range of possible futures without changing my account.

Use plain language, one primary action per section, helpful empty states, and an **Optional** label on technical tools. Put the most important information first; hide detailed models, indicators, tax tools, and backtests behind expanders.

## Essential screens
- **Overview:** portfolio value and history line graph; an optional future-value fan graph; available cash; short holdings list; watchlist; one simple time-skip control.
- **Explore stocks:** search real ticker symbols and company names, filter by sector/watchlist, and optionally scan actual historical-data signals. Mobile stock cards must have a visible Buy button.
- **Stock detail:** keep the simulated practice quote separate from actual daily market history. Explain the source and latest date. Include an easy chart, an optional technical-analysis view, price-range forecasts, a five-level model signal, and the reasons for it.
- **Portfolio:** shares, average cost, present virtual value, return, allocation, and a clear Sell action. Show the portfolio’s simulated historical value separately from an optional forecast based on actual historical stock returns.
- **Activity & funds:** deposit or withdraw virtual cash, explain cumulative profit/loss, show the transaction ledger, and allow CSV export.
- **Future simulator:** compare a selected stock or the current portfolio over one day, one week, one month, three months, or—on portfolio projections—up to five years. Let users add an optional monthly contribution. Never promise an exact future price.
- **Learning and news:** explain concepts in plain language. Clearly label generated story events as fictional simulation events; never present them as real news.

## Real symbols and data
Start with these supported U.S. tickers: **AAPL, MSFT, NVDA, AMZN, GOOGL, META, AMD, ORCL, CRM, TSLA, NKE, SBUX, COST, WMT, KO, JNJ, PFE, LLY, UNH, JPM, GS, V, XOM, CAT, DIS, NFLX**. Search and reject unsupported symbols rather than returning invented values.

Load up to ten years of actual daily OHLCV history from a market-data provider on the server. Identify the provider, price-adjustment caveats, and latest returned trading date. Label data as delayed or possibly delayed; do not imply an unofficial public feed is real-time, exchange-authorized, or guaranteed. Cache requests and handle rate limits. If real data is missing, show an honest unavailable state—**never** silently substitute simulated history.

Keep the practice market entirely separate: virtual trades, prices, balance, generated practice news and time jumps remain simulated. Show clear labels anywhere the two appear together. All trades use virtual money only.

## Historical indicators and model predictions
Calculate models from the selected symbol’s actual returned daily history—not randomized, fixed, or hand-entered forecasts. Where available, show estimates and uncertainty ranges for the next day, week, month, and three months.

Include:
- A 2,000-path Monte Carlo estimate with a median and 5th–95th percentile range.
- Linear regression, Random Forest, ARIMA(1,1,0), a simple recent-trend baseline, and GARCH(1,1) volatility. Show linear regression explicitly in the prediction comparison, with its method and historical test result.
- Walk-forward/chronological historical testing: predicted versus subsequently observed closes, direction hit rate, and price error. Keep accuracy separate from confidence and show the sample count.
- RSI, MACD, SMA/EMA crossovers, Bollinger Bands, VWAP, Stochastic RSI, ADX, Supertrend, Fibonacci reference levels, support/resistance, volume comparison, and simple trend/pattern descriptions.
- A compact model-comparison table and a short explanation of what agrees or conflicts.

Only claim a model is implemented if it actually runs on the returned data. If XGBoost or LSTM is not connected to a validated, trained runtime, label it **not available** rather than inventing a result. Do not describe a rule-based indicator ensemble as a connected AI service.

## Five-level signal and risk
Derive a signal from current actual-history indicators and model outputs:
- 🟢 **Strong Buy**
- 🟢 **Buy**
- 🟡 **Hold**
- 🟠 **Sell**
- 🔴 **Strong Sell**

Show the latest actual daily close and date, a reference entry, model target and range, protective stop, risk/reward, model agreement, relevant indicator signals, and the main reasons. The screen must state that these are educational calculations, not personal financial advice or guarantees. Signals must not claim accuracy that a historical test has not measured.

## Practice trading and learning tools
Support fractional-share virtual market orders, optional limit/stop orders, watchlists, open holdings, deposits, withdrawals, P&L, and transaction history. Validate orders on the server, prevent spending more cash than the account has, and make reset explicit.

Keep optional tools simple:
- A portfolio future-growth fan chart based on actual overlapping daily returns for the current holdings and their current weights. Clearly label it a model illustration; cash earns no assumed return unless stated.
- A stock forecast calculator using actual data.
- Historical buy-all-at-once versus monthly-purchases backtesting.
- Beta/sector stress scenarios, position-size and risk/reward explanations, and an optional tax simulator.
- A signal screener with search/filtering.
- A prediction accuracy tracker that saves the original forecast and later compares it with the first eligible actual daily close; include dates, error, direction result, range coverage, and model sample size.
- A strategy backtester for buy & hold, monthly DCA, RSI mean reversion, MACD crossover, SMA trend, and Supertrend. Show final value, return, trades, win rate, average win/loss, max drawdown, and compare against buy & hold and DCA.

## Design and engineering
Use a dark-first, uncluttered responsive design with a persistent, keyboard-accessible light/dark switch, legible numbers, forest-green positive actions, restrained red for losses, accessible focus states, and a small mobile navigation bar. Keep trade controls close to the selected company and test mobile without horizontal page scrolling.

Use Next.js App Router, PostgreSQL, and Drizzle. Keep secrets on the server. Cache external market history and validate all ticker inputs. Include loading, empty, stale-data, error, retry, order-review, order-success, and forecast-uncertainty states. Serialize mutations and never expose an external API key to the browser. If user accounts are added, isolate each account’s money, holdings, orders, watchlist, and history; never use one shared account for every visitor.

## Done means
The site builds and runs, real-history requests either return attributable data or a clear error, actual-data signals are calculated from that history, paper buys/sells affect only virtual cash and holdings, the past portfolio graph updates after account changes, and the future graph displays a range rather than a guaranteed point estimate. Test real data, model validation, trades, account isolation, deposits/withdrawals, exports, five-year simulation, and desktop/mobile screens.
