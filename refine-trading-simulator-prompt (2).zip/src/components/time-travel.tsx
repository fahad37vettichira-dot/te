"use client";

import { useState } from "react";
import { Icon } from "@/components/icons";
import { useSim, SPEED_OPTIONS } from "@/components/providers";
import { fmtDayMedium } from "@/lib/time";

export const TIME_JUMPS = [{ value: 1, label: "1 trading day" }, { value: 5, label: "1 week" }, { value: 21, label: "1 month" }, { value: 252, label: "1 year" }, { value: 1260, label: "5 years" }];

function TimeIllustration() {
  return <svg className="time-illustration" viewBox="0 0 78 72" fill="none" aria-hidden="true">
    <g stroke="currentColor" strokeWidth="1.05" strokeLinejoin="round">
      <path d="m8 48 27-14 34 16-27 15Z" fill="var(--time-base)" opacity=".55"/>
      <path d="m8 39 27-14 34 16-27 15Z" fill="var(--time-base)" opacity=".75"/>
      <path d="m8 30 27-14 34 16-27 15Z" fill="var(--time-base)"/>
      <path d="m8 25 27-14 34 16-27 15Z" fill="var(--time-top)"/>
      <path d="m8 25 0 5 34 17v-5M69 27v5L42 47"/>
      <path d="m23 25 9-4 3 8-12-4Zm10-5 9-4 3 8-12-4Z" fill="currentColor" stroke="none" transform="translate(4 2)"/>
      <path d="m16 38 0 5m33 8 0 5m13-25v5" opacity=".6"/>
    </g><g fill="currentColor"><circle cx="6" cy="14" r="1.3"/><circle cx="61" cy="9" r="1.3"/><circle cx="75" cy="44" r="1.2"/></g>
  </svg>;
}

export function TimeTravelCard({ dialog = false }: { dialog?: boolean }) {
  const { snapshot, advance, ticking, busy, setSpeed } = useSim();
  const [days, setDays] = useState(21);
  const [confirm, setConfirm] = useState(false);
  const selection = TIME_JUMPS.find(j => j.value === days)!;
  const skip = async () => {
    if (days >= 252 && !confirm) { setConfirm(true); return; }
    if (snapshot?.market.speed) await setSpeed(0);
    await advance(days);
    setConfirm(false);
  };
  return <section className={dialog ? "time-dialog" : "time-console"} aria-label="Time travel simulator">
    <div className="time-console-main">
      {!dialog && <TimeIllustration/>}
      <div className="time-intro">{!dialog && <><span className="time-eyebrow">Simulation tools</span><h2>Time travel <span className="lab-tag">LAB</span></h2></>}<p>Fast-forward your portfolio. See what a day, a month, or five years could change.</p></div>
      <div className="time-actions"><label className={dialog ? "label" : "sr-only"} htmlFor={dialog ? "time-dialog" : "time-card"}>Skip ahead by</label><select id={dialog ? "time-dialog" : "time-card"} className="select" value={days} disabled={ticking} onChange={e => { setDays(Number(e.target.value)); setConfirm(false); }}>{TIME_JUMPS.map(j => <option key={j.value} value={j.value}>{j.label}</option>)}</select>
        <button type="button" onClick={() => void skip()} disabled={busy || ticking || !snapshot} className="btn btn-time"><Icon name="forward" size={14}/>{ticking ? "Advancing…" : confirm ? `Yes, skip ${selection.label}` : "Skip ahead"}</button>
      </div>
    </div>
    {confirm && <div className="time-confirm" role="status"><span>Skip {selection.label}? Prices will change and pending orders may fill. You can’t rewind this jump.</span><button type="button" className="btn btn-xs" onClick={() => setConfirm(false)}>Cancel</button></div>}
    {dialog && <><p className="clock-meta"><span><i className="dot"/> {snapshot?.market.speed ? "Running" : "Paused"}</span>{snapshot ? fmtDayMedium(snapshot.market.day, snapshot.market.epoch) : "Loading…"}</p><details className="mt-5 border-t border-[var(--line)] pt-4"><summary className="cursor-pointer text-xs text-[var(--muted)]">Run time automatically instead</summary><div className="field mt-4"><label className="label" htmlFor="auto-time-speed">Automatic speed</label><select id="auto-time-speed" className="select" value={snapshot?.market.speed || 0} disabled={busy} onChange={e => void setSpeed(Number(e.target.value))}>{SPEED_OPTIONS.map(s => <option key={s.value} value={s.value}>{s.label}</option>)}</select><p className="hint">Prices move while this tab is visible. Opening a trade or adding funds pauses time.</p></div></details></>}
  </section>;
}
