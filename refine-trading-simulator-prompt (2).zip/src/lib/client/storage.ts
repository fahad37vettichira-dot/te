import { createInitialState, type SimState } from "./market";

export const STORAGE_KEY = "paper-trade-sim-v1";

export function loadState(): SimState {
  if (typeof window === "undefined") return createInitialState();
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as SimState;
      if (parsed && parsed.version === 1 && Array.isArray(parsed.tickers) && parsed.tickers.length && parsed.market && parsed.account) return parsed;
    }
  } catch {
    // Corrupt or inaccessible storage: start fresh below.
  }
  const fresh = createInitialState();
  saveState(fresh);
  return fresh;
}

export function saveState(state: SimState): boolean {
  if (typeof window === "undefined") return false;
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    return true;
  } catch {
    return false;
  }
}

export function clearState(): void {
  if (typeof window === "undefined") return;
  try { window.localStorage.removeItem(STORAGE_KEY); } catch { /* ignore */ }
}
