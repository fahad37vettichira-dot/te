"use client";

import Link from "next/link";
import { useSim } from "@/components/providers";
import { Icon } from "@/components/icons";
import { PageLoading, PanelHeader, Empty } from "@/components/ui";
import { PortfolioChart } from "@/components/portfolio-chart";
import { HoldingsTable } from "@/components/holdings-table";
import { TimeTravelCard } from "@/components/time-travel";
import { NewsCard } from "@/components/widgets";
import { OverviewMetrics, WatchlistCard } from "@/components/overview-cards";

export default function Overview() {
  const { snapshot, loading, openCash } = useSim();
  if (loading && !snapshot) return <PageLoading/>;
  if (!snapshot) return <Empty title="Your workspace couldn’t load" hint="Use Try again above to reopen your local practice account."/>;
  return <div className="dashboard">
    <div className="overview-heading"><div><div className="workspace-kicker"><span/>Trading workspace</div><h1>Portfolio overview</h1><p>Your investments, performance, and market activity at a glance.</p></div>
      <div className="overview-actions"><button type="button" className="btn" onClick={() => openCash("deposit")}><Icon name="plus" size={15}/>Add funds</button><Link href="/markets" className="btn btn-primary"><Icon name="arrows" size={15}/>Trade stocks</Link></div>
    </div>
    <OverviewMetrics/>
    <div className="overview-grid"><PortfolioChart/><WatchlistCard/></div>
    <TimeTravelCard/>
    <HoldingsTable preview/>
    <section className="panel market-brief"><PanelHeader title="Market briefing" subtitle="Fictional headlines from your simulated market." action={<Link href="/news" className="section-link">All news <Icon name="arrowRight" size={13}/></Link>}/><div className="brief-grid">{snapshot.news.slice(0, 2).map(n => <NewsCard key={n.id} item={n} epoch={snapshot.market.epoch} compact/>)}{!snapshot.news.length && <p className="hint">Stories appear as you advance simulated time.</p>}</div></section>
  </div>;
}
