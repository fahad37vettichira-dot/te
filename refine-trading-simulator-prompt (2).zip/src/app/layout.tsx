import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import { initializeAppearance } from "@/lib/appearance";
import { SimProvider } from "@/components/providers";
import { AppShell } from "@/components/shell";
import "./globals.css";

export const metadata: Metadata = {
  title: "PaperTrade — Your trading workspace",
  description: "Your private paper-trading workspace. Explore stocks, follow your portfolio and test ideas with virtual funds. All trading runs in your browser.",
  applicationName: "Paper Trade",
  icons: { icon: "/papertrade.svg" },
};
// The appearance initializer manages browser chrome without duplicating React metadata.
export const viewport: Viewport = { width: "device-width", initialScale: 1 };

export default function RootLayout({ children }: { children: ReactNode }) {
  return <html lang="en" data-theme="dark" suppressHydrationWarning>
    <head><script dangerouslySetInnerHTML={{ __html: initializeAppearance }}/></head>
    <body className="antialiased"><SimProvider><AppShell>{children}</AppShell></SimProvider></body>
  </html>;
}
