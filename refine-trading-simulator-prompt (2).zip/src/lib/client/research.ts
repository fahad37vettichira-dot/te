"use client";

import { UNIVERSE } from "@/lib/universe";
import {
  FORECAST_HORIZONS,
  getPortfolioActualReturns,
  getRealHistory,
  getRealMarketAnalysis,
  getRealMarketSummary,
  getStockActualProjection,
  makePortfolioProjection,
  type RealMarketAnalysis,
} from "@/lib/realMarket";
import { backtestStrategy, BACKTEST_STRATEGIES, type BacktestStrategyId } from "@/lib/backtest";

/* ------------------------------------------------ prediction accuracy log */

export type PredictionRecord = {
  id: number;
  symbol: string;
  modelId: string;
  horizon: string;
  horizonDays: number;
  forecastDate: string;
  targetDate: string;
  referencePrice: number;
  predictedLow: number;
  predictedMedian: number;
  predictedHigh: number;
  actualPrice: number | null;
  errorPct: number | null;
  directionCorrect: boolean | null;
  evaluatedAt: string | null;
};

const FORECAST_KEY = "paper-trade-forecast-log-v1";
const DAY_MS = 86_400_000;

function readLog(): PredictionRecord[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = window.localStorage.getItem(FORECAST_KEY);
    const parsed = raw ? (JSON.parse(raw) as PredictionRecord[]) : [];
    return Array.isArray(parsed) ? parsed : [];
  } catch { return []; }
}
function writeLog(rows: PredictionRecord[]): void {
  if (typeof window === "undefined") return;
  try { window.localStorage.setItem(FORECAST_KEY, JSON.stringify(rows.slice(-3000))); } catch { /* storage full or blocked */ }
}
function addTradingSessions(isoDate: string, sessions: number): string {
  const date = new Date(`${isoDate}T12:00:00.000Z`);
  let remaining = sessions;
  while (remaining > 0) {
    date.setUTCDate(date.getUTCDate() + 1);
    const weekday = date.getUTCDay();
    if (weekday !== 0 && weekday !== 6) remaining--;
  }
  return date.toISOString().slice(0, 10);
}

/** Save the first forecast per real-data date, then score matured forecasts against actual closes. */
export function captureAndEvaluateForecasts(analysis: RealMarketAnalysis): PredictionRecord[] {
  const rows = readLog();
  let nextId = rows.reduce((m, r) => Math.max(m, r.id), 0) + 1;
  for (const model of analysis.forecasts) {
    for (const horizon of FORECAST_HORIZONS) {
      const p = model.forecasts[horizon.key];
      if (![analysis.latestClose, p.low, p.median, p.high].every(Number.isFinite)) continue;
      const exists = rows.some(r => r.symbol === analysis.symbol && r.modelId === model.id && r.forecastDate === analysis.latestDate && r.horizon === horizon.key);
      if (exists) continue;
      rows.push({ id: nextId++, symbol: analysis.symbol, modelId: model.id, horizon: horizon.key, horizonDays: horizon.days, forecastDate: analysis.latestDate, targetDate: addTradingSessions(analysis.latestDate, horizon.days), referencePrice: analysis.latestClose, predictedLow: p.low, predictedMedian: p.median, predictedHigh: p.high, actualPrice: null, errorPct: null, directionCorrect: null, evaluatedAt: null });
    }
  }
  const latestTime = Date.parse(`${analysis.latestDate}T23:59:59.999Z`);
  for (const r of rows) {
    if (r.symbol !== analysis.symbol || r.actualPrice !== null) continue;
    const targetTime = Date.parse(`${r.targetDate}T00:00:00.000Z`);
    if (!Number.isFinite(targetTime) || targetTime > latestTime) continue;
    const realized = analysis.history.find(bar => { const t = Date.parse(`${bar.date}T00:00:00.000Z`); return t >= targetTime && t <= targetTime + 7 * DAY_MS; });
    if (!realized) continue;
    r.actualPrice = realized.adjustedClose;
    r.errorPct = r.predictedMedian > 0 ? Math.abs(realized.adjustedClose - r.predictedMedian) / r.predictedMedian : null;
    r.directionCorrect = (r.predictedMedian > r.referencePrice) === (realized.adjustedClose > r.referencePrice);
    r.evaluatedAt = new Date().toISOString();
  }
  writeLog(rows);
  return rows.filter(r => r.symbol === analysis.symbol).sort((a, b) => b.id - a.id).slice(0, 80);
}

/* --------------------------------------------------------- client wrappers */

export type ResearchData = RealMarketAnalysis & { predictionHistory: PredictionRecord[] };

export async function loadResearch(symbol: string): Promise<ResearchData> {
  const analysis = await getRealMarketAnalysis(symbol);
  return { ...analysis, predictionHistory: captureAndEvaluateForecasts(analysis) };
}

export async function loadStockProjection(symbol: string, startValue: number, horizonDays: number, monthlyContribution: number) {
  if (!Number.isFinite(startValue) || startValue <= 0 || startValue > 5_000_000) throw new Error("Choose a starting amount from $0.01 to $5,000,000.");
  if (![63, 252, 756, 1260].includes(horizonDays)) throw new Error("Choose a 3-month, 1-year, 3-year, or 5-year forecast.");
  if (!Number.isFinite(monthlyContribution) || monthlyContribution < 0 || monthlyContribution > 100_000) throw new Error("Monthly additions must be between $0 and $100,000.");
  return getStockActualProjection(symbol, startValue, horizonDays, monthlyContribution);
}

export async function loadPortfolioProjection(input: { startValue: number; horizonDays: number; positions: Array<{ symbol: string; weight: number }>; monthlyContribution?: number }) {
  const { startValue, horizonDays, positions } = input;
  const monthlyContribution = input.monthlyContribution ?? 0;
  if (!Number.isFinite(startValue) || startValue <= 0 || startValue > 100_000_000) throw new Error("Choose a valid current portfolio value.");
  if (![63, 252, 756, 1260].includes(horizonDays)) throw new Error("Choose a 3-month, one, three, or five-year portfolio projection.");
  if (!Number.isFinite(monthlyContribution) || monthlyContribution < 0 || monthlyContribution > 100_000) throw new Error("Monthly additions must be between $0 and $100,000.");
  if (positions.length > 26) throw new Error("Portfolio positions are invalid.");
  const actual = await getPortfolioActualReturns(positions);
  const seed = positions.reduce((n, p) => n + p.symbol.split("").reduce((x, c) => x * 31 + c.charCodeAt(0), 1), Math.round(startValue * 100)) + horizonDays;
  const projection = makePortfolioProjection({ returns: actual.returns, startValue, horizonDays, monthlyContribution, seed });
  return {
    ...projection,
    latestHistoryDate: actual.latestDate,
    dataSymbols: actual.dataSymbols,
    investedWeight: actual.investedWeight,
    cashWeight: Math.max(0, 1 - actual.investedWeight),
    source: "Yahoo Finance historical chart",
    sourceType: "Unofficial daily historical feed; may be delayed.",
    method: "2,000 Monte Carlo paths generated from your current paper-portfolio weights and overlapping historical daily stock returns. Cash is assumed to earn 0%; requested monthly contributions are invested in the same stock weights.",
  };
}

export async function runBacktest(symbol: string, strategy: BacktestStrategyId, lookback: number, budget: number, feeBps = 10) {
  if (!BACKTEST_STRATEGIES.some(s => s.id === strategy)) throw new Error("Choose a supported backtest strategy.");
  if (![63, 252, 504, 756, 1260].includes(lookback)) throw new Error("Choose a 3-month, 1-year, 2-year, 3-year, or 5-year backtest.");
  if (!Number.isFinite(budget) || budget <= 0 || budget > 5_000_000) throw new Error("Choose a budget from $0.01 to $5,000,000.");
  const { history } = await getRealHistory(symbol);
  return backtestStrategy({ symbol, history, strategy, lookback, budget, feeBps });
}

export type ScreenerResult = {
  rows: Array<Awaited<ReturnType<typeof getRealMarketSummary>> & { sector: string }>;
  unavailable: string[];
  latestDate: string;
  source: string;
  sourceType: string;
  disclaimer: string;
};

export async function runScreener(): Promise<ScreenerResult> {
  const rows: ScreenerResult["rows"] = [];
  const unavailable: string[] = [];
  let cursor = 0;
  await Promise.all(Array.from({ length: 4 }, async () => {
    while (cursor < UNIVERSE.length) {
      const ticker = UNIVERSE[cursor++];
      try { rows.push({ ...(await getRealMarketSummary(ticker.symbol)), sector: ticker.sector }); }
      catch { unavailable.push(ticker.symbol); }
    }
  }));
  rows.sort((a, b) => b.score - a.score);
  if (!rows.length) throw new Error("The real historical feed could not be reached from this browser for any supported symbol. No simulated prices were used in this scan.");
  return { rows, unavailable, latestDate: rows.map(r => r.latestDate).sort().at(-1) ?? "", source: "Yahoo Finance historical chart", sourceType: "Unofficial daily feed; may be delayed.", disclaimer: "Signals are model output from historical prices, not financial advice or a promise of future returns." };
}
