"use client";

import { useState } from "react";
import { useSim } from "@/components/providers";
import { Icon } from "@/components/icons";
import { LineChart } from "@/components/charts";
import { fmtMoney, fmtPct, fmtSignedMoney, toneClass } from "@/lib/format";
import { BACKTEST_STRATEGIES, type BacktestResult, type BacktestStrategyId } from "@/lib/backtest";
import { runBacktest as runBacktestLocal } from "@/lib/client/research";

export default function AdvancedLab() {
  const { snapshot } = useSim();
  const [shock, setShock] = useState(-.1);
  const [symbol, setSymbol] = useState("AAPL");
  const [lookback, setLookback] = useState(252);
  const [strategy, setStrategy] = useState<BacktestStrategyId>("rsi");
  const [budget, setBudget] = useState("10000");
  const [running, setRunning] = useState(false);
  const [result, setResult] = useState<BacktestResult | null>(null);
  const [error, setError] = useState("");
  if (!snapshot) return null;
  const impact = snapshot.holdings.reduce((sum, h) => sum + h.value * Math.max(-1, h.beta * shock), 0);
  const budgetValue = Number(budget || 0);

  const runBacktest = async () => {
    if (running) return;
    if (!Number.isFinite(budgetValue) || budgetValue <= 0 || budgetValue > 5_000_000) {
      setError("Choose a backtest budget from $0.01 to $5,000,000.");
      return;
    }
    setRunning(true);
    setError("");
    try {
      const body = await runBacktestLocal(symbol, strategy, lookback, budgetValue, 10);
      setResult(body as BacktestResult);
    } catch (e) {
      setResult(null);
      setError(e instanceof Error ? e.message : "Couldn’t run this backtest.");
    } finally {
      setRunning(false);
    }
  };

  const labels = result?.labels.map(date => new Date(`${date}T12:00:00Z`).toLocaleDateString("en-US", { month: "short", day: "numeric", timeZone: "UTC" })) ?? [];

  return <div className="space-y-7">
    <div>
      <h3 className="text-sm font-medium">What if the whole market moved?</h3>
      <p className="hint mt-2">A quick stress test for your current holdings. It won’t change your account.</p>
      <div className="mt-4 flex flex-wrap items-center gap-4">
        <select className="select !w-auto" aria-label="Market shock scenario" value={shock} onChange={e => setShock(Number(e.target.value))}>
          <option value={-.05}>A small dip (−5%)</option>
          <option value={-.1}>A market correction (−10%)</option>
          <option value={-.2}>A sharp drop (−20%)</option>
          <option value={.15}>A strong rally (+15%)</option>
        </select>
        <p className="text-xs text-[var(--muted)]">Estimated account change <strong className={`tnum ml-2 text-base font-medium ${toneClass(impact)}`}>{fmtSignedMoney(impact)}</strong></p>
      </div>
      <p className="mt-3 text-[10px] text-[var(--muted)]">Uses each stock’s sensitivity to the market (beta). Ignores liquidity and company-specific news.</p>
    </div>

    <div className="border-t border-[var(--line)] pt-6">
      <h3 className="text-sm font-medium">Strategy backtester</h3>
      <p className="hint mt-2">Test a rule on the stock’s actual reported daily history. This does not place trades.</p>
      <div className="mt-4 flex flex-wrap items-end gap-3">
        <div className="field"><label className="label" htmlFor="backtest-stock">Stock</label><select id="backtest-stock" className="select !w-auto max-w-full" value={symbol} onChange={e => setSymbol(e.target.value)}>{snapshot.tickers.map(t => <option key={t.symbol} value={t.symbol}>{t.symbol} — {t.name}</option>)}</select></div>
        <div className="field"><label className="label" htmlFor="backtest-strategy">Strategy</label><select id="backtest-strategy" className="select !w-auto" value={strategy} onChange={e => setStrategy(e.target.value as BacktestStrategyId)}>{BACKTEST_STRATEGIES.map(s => <option key={s.id} value={s.id}>{s.label}</option>)}</select></div>
        <div className="field"><label className="label" htmlFor="backtest-period">Period</label><select id="backtest-period" className="select !w-auto" value={lookback} onChange={e => setLookback(Number(e.target.value))}><option value={63}>Last 3 months</option><option value={252}>Last year</option><option value={504}>Last 2 years</option><option value={756}>Last 3 years</option><option value={1260}>Last 5 years</option></select></div>
        <div className="field"><label className="label" htmlFor="backtest-budget">Budget ($)</label><input id="backtest-budget" className="input !w-36" inputMode="decimal" value={budget} onChange={e => setBudget(e.target.value.replace(/[^0-9.]/g, ""))}/></div>
        <button className="btn btn-primary" disabled={running} onClick={() => void runBacktest()}>{running ? "Running backtest…" : "Run backtest"}<Icon name="arrowUpRight" size={13}/></button>
      </div>
      <p className="hint mt-3">{BACKTEST_STRATEGIES.find(s => s.id === strategy)?.description} Signals use data available at each close; trades execute at that close with a 10 bps fee.</p>
      {error && <p className="mt-4 text-xs down" role="alert">{error}</p>}
      {result && <div className="mt-6">
        <div className="mb-4 flex flex-wrap items-center justify-between gap-2"><h4 className="text-xs text-[var(--muted)]">{result.strategyLabel} · {result.symbol} · {result.startDate} to {result.endDate}</h4><span className="pill">{result.bars} daily bars</span></div>
        <LineChart series={[
          { name: result.strategyLabel, values: result.strategyEquity, color: "var(--chart-a)", fill: true },
          { name: "Buy & hold", values: result.buyHoldEquity, color: "var(--benchmark)", dashed: true },
          { name: "Monthly DCA", values: result.dcaEquity, color: "var(--violet)", dashed: true },
        ]} labels={labels} height={190} formatValue={v => fmtMoney(v, 0)}/>
        <div className="mt-5 grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-6">
          {[
            { label: "Final value", value: fmtMoney(result.finalValue) },
            { label: "Total return", value: fmtPct(result.totalReturn, 1) },
            { label: "Trades", value: String(result.trades) },
            { label: "Win rate", value: result.winRate === null ? "—" : fmtPct(result.winRate, 0) },
            { label: "Avg win", value: result.avgWin === null ? "—" : fmtSignedMoney(result.avgWin) },
            { label: "Avg loss", value: result.avgLoss === null ? "—" : fmtSignedMoney(result.avgLoss) },
            { label: "Max drawdown", value: fmtPct(result.maxDrawdown, 1) },
            { label: "Buy & hold", value: fmtMoney(result.buyHoldFinal) },
            { label: "Monthly DCA", value: fmtMoney(result.dcaFinal) },
          ].map(metric => <div key={metric.label} className="rounded-lg border border-[var(--line)] bg-[var(--panel)] p-3"><p className="text-[9px] text-[var(--muted)]">{metric.label}</p><p className="tnum mt-1 text-[13px] font-medium">{metric.value}</p></div>)}
        </div>
        <p className="hint mt-4">{result.assumptions}</p>
      </div>}
    </div>
  </div>;
}
