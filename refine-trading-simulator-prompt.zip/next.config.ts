import type { NextConfig } from "next";

// Fully static build: no server, no database. Output lands in ./out.
const nextConfig: NextConfig = {
  output: "export",
  trailingSlash: true,
  images: { unoptimized: true },
};

export default nextConfig;
