const { chromium, expect } = require('@playwright/test');
const assert = require('node:assert/strict');
const base = process.env.TEST_BASE_URL || 'http://127.0.0.1:8123';

(async () => {
  const browser = await chromium.launch({ headless: true, args: ['--no-sandbox'] });
  const context = await browser.newContext({ viewport: { width: 1440, height: 1000 }, reducedMotion: 'reduce' });
  const page = await context.newPage();
  page.setDefaultTimeout(20000);
  const errors = [];
  const apiCalls = [];
  page.on('pageerror', e => errors.push(e.message));
  page.on('request', r => { if (r.url().includes('/api/')) apiCalls.push(r.url()); });
  const noOverflow = async p => assert(await p.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1), `Page must fit viewport: ${p.url()}`);
  const stored = () => page.evaluate(() => JSON.parse(localStorage.getItem('paper-trade-sim-v1')));

  try {
    await page.goto(base + '/', { waitUntil: 'networkidle' });
    await expect(page.getByRole('heading', { name: 'Portfolio overview' })).toBeVisible();
    await expect(page.getByText('Buying power', { exact: true })).toBeVisible();
    await noOverflow(page);
    let s = await stored();
    assert(s && s.account && s.tickers.length === 26, 'Simulation state persisted to localStorage');
    const startCash = s.account.cash;
    const startDay = s.market.day;

    // Buy from Explore
    await page.getByRole('link', { name: 'Explore stocks', exact: true }).first().click();
    await page.getByLabel('Search stocks').fill('KO');
    await page.getByRole('button', { name: 'Buy', exact: true }).click();
    let dialog = page.getByRole('dialog');
    await dialog.locator('#trade-amount-KO').fill('100');
    await dialog.getByRole('button', { name: 'Review order', exact: true }).click();
    await dialog.getByRole('button', { name: 'Confirm virtual purchase', exact: true }).click();
    await expect(dialog.getByRole('heading', { name: 'Nicely done!' })).toBeVisible();
    await dialog.getByRole('button', { name: 'Done', exact: true }).click();
    s = await stored();
    const held = s.holdings.find(h => h.symbol === 'KO');
    assert(held && held.shares > 0, 'Purchase stored locally');
    assert(Math.abs(startCash - s.account.cash - 100) < 0.02, 'Cash reduced by purchase');

    // Reload persists
    await page.reload({ waitUntil: 'networkidle' });
    s = await stored();
    assert(s.holdings.some(h => h.symbol === 'KO'), 'Holding survives reload');

    // Sell from portfolio
    await page.goto(base + '/portfolio/', { waitUntil: 'networkidle' });
    await page.getByRole('row').filter({ hasText: 'KO' }).getByRole('button', { name: 'Sell', exact: true }).click();
    dialog = page.getByRole('dialog');
    await dialog.locator('#trade-amount-KO').fill(String(held.shares));
    await dialog.getByRole('button', { name: 'Review order', exact: true }).click();
    await dialog.getByRole('button', { name: 'Confirm virtual sale', exact: true }).click();
    await expect(dialog.getByRole('heading', { name: 'Nicely done!' })).toBeVisible();
    await dialog.getByRole('button', { name: 'Done', exact: true }).click();
    s = await stored();
    assert(!s.holdings.some(h => h.symbol === 'KO'), 'Sell removed holding');
    assert(Math.abs(s.account.cash - startCash) < 0.02, 'Round trip returns cash');

    // Deposit / withdraw
    await page.getByRole('button', { name: 'Add funds', exact: true }).click();
    dialog = page.getByRole('dialog');
    await dialog.locator('#fund-amount').fill('100');
    await dialog.getByRole('button', { name: 'Add $100.00 in virtual cash', exact: true }).click();
    await expect(dialog).toHaveCount(0);
    s = await stored();
    assert(Math.abs(s.account.cash - (startCash + 100)) < 0.02, 'Deposit applied');

    // Time travel 1 day + 5 year confirm gate
    await page.goto(base + '/', { waitUntil: 'networkidle' });
    await page.locator('#time-card').selectOption('1');
    await page.getByRole('button', { name: 'Skip ahead', exact: true }).click();
    await expect.poll(async () => (await stored()).market.day).toBe(startDay + 1);
    await page.locator('#time-card').selectOption('1260');
    await page.getByRole('button', { name: 'Skip ahead', exact: true }).click();
    await expect(page.getByRole('button', { name: 'Yes, skip 5 years', exact: true })).toBeVisible();
    await page.getByRole('button', { name: 'Yes, skip 5 years', exact: true }).click();
    await expect.poll(async () => (await stored()).market.day, { timeout: 60000 }).toBe(startDay + 1 + 1260);
    assert((await stored()).history.AAPL.length > 1000, 'Daily history grows on jump');

    // Stock page renders locally; research panel is honest when feed blocked
    await page.goto(base + '/markets/AAPL/', { waitUntil: 'networkidle' });
    await expect(page.locator('main h1')).toHaveText(/Apple/);
    await expect(page.getByText(/Real market history/).first()).toBeVisible({ timeout: 30000 });
    const text = await page.locator('main').innerText();
    assert(!text.includes('NaN'), 'No NaN on stock page');

    // CSV export is client-side
    await page.goto(base + '/activity/', { waitUntil: 'networkidle' });
    const [download] = await Promise.all([page.waitForEvent('download'), page.getByRole('button', { name: /Download history/ }).click()]);
    assert.equal(download.suggestedFilename(), 'paper-trade-activity.csv');

    for (const path of ['/markets/', '/news/', '/simulations/', '/portfolio/']) {
      await page.goto(base + path, { waitUntil: 'networkidle' });
      await expect(page.locator('main h1')).toBeVisible();
      await noOverflow(page);
    }
    const mobile = await (await browser.newContext({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true })).newPage();
    mobile.on('pageerror', e => errors.push(e.message));
    for (const path of ['/', '/markets/', '/markets/AAPL/', '/portfolio/', '/activity/']) {
      await mobile.goto(base + path, { waitUntil: 'networkidle' });
      await expect(mobile.locator('main h1')).toBeVisible();
      await noOverflow(mobile);
    }
    assert.deepEqual(apiCalls, [], 'No /api calls from the static site');
    assert.deepEqual(errors, [], 'No browser runtime errors');
    console.log('PASS: static site — localStorage persistence, buy/sell, deposit, 1-day and 5-year time travel, stock page, CSV export, desktop+mobile routes, zero API calls.');
  } finally {
    await browser.close();
  }
})().catch(error => { console.error(error); process.exitCode = 1; });
