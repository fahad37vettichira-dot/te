"use client";

import { useEffect, useId, useRef, type ReactNode } from "react";
import { Icon } from "@/components/icons";
import { fmtSignedPct } from "@/lib/format";

export function Panel({ children, className = "" }: { children: ReactNode; className?: string }) {
  return <section className={`panel ${className}`}>{children}</section>;
}

export function PanelHeader({ title, subtitle, action, className = "" }: { title: ReactNode; subtitle?: ReactNode; action?: ReactNode; className?: string }) {
  return <div className={`panel-head ${className}`}><div><h2 className="panel-title">{title}</h2>{subtitle && <p className="panel-subtitle">{subtitle}</p>}</div>{action && <div>{action}</div>}</div>;
}

export function Delta({ value, className = "", decimals = 2, showIcon = true }: { value: number; className?: string; decimals?: number; showIcon?: boolean }) {
  return <span className={`tnum inline-flex items-center gap-1 text-xs ${value > 0.00001 ? "up" : value < -0.00001 ? "down" : "muted"} ${className}`}>{showIcon && <Icon name={value < 0 ? "arrowDownRight" : "arrowUpRight"} size={13} />}{fmtSignedPct(value, decimals)}</span>;
}

export function Pill({ children, tone = "neutral", className = "" }: { children: ReactNode; tone?: "neutral" | "up" | "down" | "warn" | "accent" | "violet"; className?: string }) {
  return <span className={`pill ${tone === "neutral" ? "" : `pill-${tone}`} ${className}`}>{children}</span>;
}

export function StatCard({ label, value, delta, sub, icon }: { label: string; value: ReactNode; delta?: ReactNode; sub?: ReactNode; icon?: ReactNode; accent?: "up" | "down" | "accent" }) {
  return <div className="panel stat-block"><div className="card-label flex items-center justify-between gap-2">{label}{icon}</div><div className="value tnum">{value}</div>{delta && <div className="mt-2 text-xs">{delta}</div>}{sub && <div className="hint mt-1">{sub}</div>}</div>;
}

export function Segmented<T extends string | number>({ options, value, onChange, className = "" }: { options: Array<{ value: T; label: string }>; value: T; onChange: (next: T) => void; className?: string }) {
  return <div className={`segment ${className}`} role="group">{options.map(option => <button type="button" key={option.value} aria-pressed={option.value === value} data-active={option.value === value} onClick={() => onChange(option.value)} className="segment-item">{option.label}</button>)}</div>;
}

export function Modal({ open, onClose, title, subtitle, children, footer, width = "max-w-md" }: { open: boolean; onClose: () => void; title: string; subtitle?: string; children: ReactNode; footer?: ReactNode; width?: string }) {
  const id = useId();
  const ref = useRef<HTMLDivElement>(null);
  const closeRef = useRef(onClose);
  useEffect(() => { closeRef.current = onClose; }, [onClose]);
  useEffect(() => {
    if (!open) return;
    const before = document.activeElement as HTMLElement | null;
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const timer = setTimeout(() => ref.current?.focus(), 0);
    const keydown = (event: KeyboardEvent) => {
      if (event.key === "Escape") closeRef.current();
      if (event.key !== "Tab") return;
      const focusables = ref.current?.querySelectorAll<HTMLElement>('a[href],button:not([disabled]),input:not([disabled]),select:not([disabled]),summary,[tabindex="0"]');
      if (!focusables?.length) { event.preventDefault(); return; }
      const first = focusables[0];
      const last = focusables[focusables.length - 1];
      if (event.shiftKey && (document.activeElement === first || document.activeElement === ref.current)) { event.preventDefault(); last.focus(); }
      else if (!event.shiftKey && (document.activeElement === last || document.activeElement === ref.current)) { event.preventDefault(); first.focus(); }
    };
    document.addEventListener("keydown", keydown);
    return () => { clearTimeout(timer); document.body.style.overflow = previousOverflow; document.removeEventListener("keydown", keydown); before?.focus(); };
  }, [open]);
  if (!open) return null;
  return <div className="fixed inset-0 z-[100] flex items-end justify-center p-2 sm:items-center sm:p-6"><div className="modal-backdrop" onClick={onClose} aria-hidden="true" /><div ref={ref} tabIndex={-1} className={`modal-card relative z-10 max-h-[92dvh] w-full overflow-y-auto outline-none ${width}`} role="dialog" aria-modal="true" aria-labelledby={id}><div className="flex items-start justify-between gap-4 px-6 pt-6 pb-5"><div><h2 id={id} className="text-xl font-medium tracking-tight">{title}</h2>{subtitle && <p className="hint mt-2">{subtitle}</p>}</div><button type="button" aria-label="Close dialog" className="btn btn-ghost btn-icon shrink-0" onClick={onClose}><Icon name="close" size={18} /></button></div><div className="px-6 pb-6">{children}</div>{footer && <div className="border-t border-[var(--line)] px-6 py-4">{footer}</div>}</div></div>;
}

export function Empty({ title, hint, icon }: { title: string; hint?: string; icon?: ReactNode }) {
  return <div className="flex flex-col items-center justify-center gap-3 px-6 py-10 text-center"><div className="grid h-11 w-11 place-items-center rounded-full bg-[#eff4ec] text-[#63815f]">{icon || <Icon name="portfolio" size={20} />}</div><p className="text-sm font-medium">{title}</p>{hint && <p className="hint max-w-xs">{hint}</p>}</div>;
}

export function Skeleton({ className = "" }: { className?: string }) { return <div className={`skeleton ${className}`} aria-hidden="true" />; }
export function PageLoading() { return <div className="page-stack" aria-label="Loading your account"><Skeleton className="h-12 w-64" /><div className="overview-grid"><Skeleton className="h-[350px]" /><Skeleton className="h-[350px]" /></div><Skeleton className="h-[230px]" /></div>; }

export function PageHeader({ eyebrow, title, subtitle, actions }: { eyebrow?: string; title: string; subtitle?: string; actions?: ReactNode }) {
  return <div className="page-heading"><div>{eyebrow && <span className="eyebrow mb-2 block">{eyebrow}</span>}<h1>{title}</h1>{subtitle && <p>{subtitle}</p>}</div>{actions && <div className="flex items-center gap-2">{actions}</div>}</div>;
}

export function InfoRow({ label, value, tone }: { label: ReactNode; value: ReactNode; tone?: string }) {
  return <div className="flex items-center justify-between gap-4 py-2 text-xs"><span className="text-[var(--muted)]">{label}</span><span className={`tnum font-medium ${tone || ""}`}>{value}</span></div>;
}
