"use client";

import Link from "next/link";
import { useState } from "react";
import { useSim } from "./providers";
import { Icon, type IconName } from "./icons";
import { Sparkline } from "./charts";
import { StockLogo } from "./stock-logo";
import { Modal, Empty } from "./ui";
import { fmtMoney, fmtSignedMoney, fmtSignedPct, toneClass } from "@/lib/format";

function MetricHeading({ name, tone, icon }: { name: string; tone: string; icon: IconName }) {
  return <div className="metric-heading"><span className={`metric-icon ${tone}`}><Icon name={icon} size={16}/></span><h2>{name}</h2></div>;
}
export function OverviewMetrics() {
  const { snapshot } = useSim();
  if (!snapshot) return null;
  const { totals, holdings, equityCurve } = snapshot;
  const cashRatio = totals.portfolioValue > 0 ? Math.max(0, Math.min(1, totals.cash / totals.portfolioValue)) : 0;
  return <section className="metrics-grid" aria-label="Account summary">
    <article className="metric-card featured-metric"><MetricHeading name="Portfolio value" tone="mint" icon="wallet"/><div className="metric-value tnum">{fmtMoney(totals.portfolioValue)}</div><div className="metric-foot"><span className={`change-tag ${toneClass(totals.totalPnl)}`}><Icon name={totals.totalPnl >= 0 ? "arrowUpRight" : "arrowDownRight"} size={12}/>{fmtSignedPct(totals.totalPnlPct)}</span><span>all time</span></div><div className="metric-spark"><Sparkline values={equityCurve.slice(-30).map(v => v.value)} width={64} height={24}/></div></article>
    <article className="metric-card"><MetricHeading name="Buying power" tone="blue" icon="layers"/><div className="metric-value tnum">{fmtMoney(totals.cash)}</div><div className="metric-foot"><span className="tiny-dot blue"/><span>Available virtual cash</span></div></article>
    <article className="metric-card"><MetricHeading name="Total return" tone="purple" icon="return"/><div className={`metric-value tnum ${toneClass(totals.totalPnl)}`}>{fmtSignedMoney(totals.totalPnl)}</div><div className="metric-foot"><span className={`day-arrow ${toneClass(totals.dayPnl)}`}><Icon name={totals.dayPnl >= 0 ? "arrowUpRight" : "arrowDownRight"} size={13}/>{fmtSignedMoney(totals.dayPnl)}</span><span>today</span></div></article>
    <article className="metric-card"><MetricHeading name="Invested capital" tone="amber" icon="pie"/><div className="metric-value tnum">{fmtMoney(totals.investedValue)}</div><div className="metric-foot"><span className="allocation-bar" aria-hidden="true"><i style={{ width: `${(1 - cashRatio) * 100}%` }}/></span><span>{holdings.length} open position{holdings.length === 1 ? "" : "s"}</span></div></article>
  </section>;
}

export function WatchlistCard() {
  const { snapshot, watch, busy } = useSim();
  const [manage, setManage] = useState(false);
  const [query, setQuery] = useState("");
  if (!snapshot) return null;
  const order = ["AAPL", "MSFT", "NVDA", "TSLA", "JPM", "LLY"];
  const watched = snapshot.tickers.filter(t => t.watched).sort((a, b) => (order.includes(a.symbol) ? order.indexOf(a.symbol) : 40) - (order.includes(b.symbol) ? order.indexOf(b.symbol) : 40));
  const filtered = snapshot.tickers.filter(t => `${t.symbol} ${t.name}`.toLowerCase().includes(query.toLowerCase().trim()));
  return <section className="panel watch-panel">
    <div className="card-heading"><h2>Watchlist <span className="count-badge">{watched.length}</span></h2><button type="button" className="icon-action" onClick={() => setManage(true)} aria-label="Manage watchlist" title="Manage watchlist"><Icon name="plus" size={17}/></button></div>
    <div className="watch-columns"><span>Symbol</span><span>Price / change</span></div>
    <div className="watch-rows">{watched.slice(0, 5).map(t => <Link key={t.symbol} className="watch-row" href={`/markets/${t.symbol}`} aria-label={`View ${t.name} (${t.symbol})`}>
      <StockLogo symbol={t.symbol} size={32}/><span className="watch-identity"><strong>{t.symbol}</strong><small>{t.name.replace(" Corp.", "").replace(" Inc.", "").replace(" Inc", "")}</small></span><Sparkline className="watch-spark" values={t.spark} tone={t.changePct >= 0 ? "up" : "down"} width={50} height={23}/><span className="watch-quote"><strong>{fmtMoney(t.price)}</strong><small className={toneClass(t.changePct)}>{fmtSignedPct(t.changePct)}</small></span>
    </Link>)}{!watched.length && <Empty title="Your watchlist is empty" hint="Use the plus button to follow a company." icon={<Icon name="star" size={18}/>}/>}</div>
    <Link href="/markets?view=watchlist" className="watch-footer">View watchlist <Icon name="arrowRight" size={13}/></Link>
    <Modal open={manage} onClose={() => { setManage(false); setQuery(""); }} title="Manage watchlist" subtitle="Choose the companies you want to follow in your workspace."><label className="watch-search"><Icon name="search" size={16}/><input aria-label="Find a company" className="input" placeholder="Search company or symbol…" value={query} onChange={e => setQuery(e.target.value)}/></label><div className="manage-watch-list">{filtered.map(t => <div className="manage-watch-row" key={t.symbol}><StockLogo symbol={t.symbol} size={32}/><span className="watch-identity"><strong>{t.symbol}</strong><small>{t.name}</small></span><button type="button" className={`btn btn-xs ${t.watched ? "following" : ""}`} disabled={busy} aria-pressed={t.watched} aria-label={`${t.watched ? "Unfollow" : "Follow"} ${t.symbol}`} onClick={() => void watch(t.symbol)}><Icon name={t.watched ? "check" : "plus"} size={12}/>{t.watched ? "Following" : "Follow"}</button></div>)}{!filtered.length && <p className="hint py-5 text-center">No matching companies.</p>}</div><button className="btn btn-primary w-full mt-5" type="button" onClick={() => setManage(false)}>Done</button></Modal>
  </section>;
}
