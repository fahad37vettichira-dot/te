"use client";

import Link from "next/link";
import { Icon } from "./icons";
import { StockLogo } from "./stock-logo";
import { Empty } from "./ui";
import { useSim } from "./providers";
import { fmtMoney, fmtShares, fmtSignedMoney, fmtSignedPct, toneClass } from "@/lib/format";

export function HoldingsTable({ preview = false }: { preview?: boolean }) {
  const { snapshot, openQuickTrade } = useSim();
  if (!snapshot) return null;
  const rows = preview ? snapshot.holdings.slice(0, 4) : snapshot.holdings;
  return <section className="panel holdings-panel">
    <div className="card-heading"><h2>{preview ? "Your holdings" : "What you own"} <span className="count-badge">{snapshot.holdings.length}</span></h2>{preview ? <Link href="/portfolio" className="section-link">View portfolio <Icon name="arrowRight" size={14}/></Link> : <Link href="/markets" className="section-link">Explore stocks <Icon name="arrowRight" size={14}/></Link>}</div>
    {rows.length ? <><div className="table-scroll portfolio-full-table"><table className="data-table holdings-table"><thead><tr><th>Asset</th><th className="text-right">Shares</th><th className="text-right">Price</th><th className="text-right">Market value</th><th className="text-right">Total return</th><th className="text-right">Allocation</th>{!preview && <th aria-label="Trade"/>}</tr></thead><tbody>{rows.map(h => <tr key={h.symbol}>
      <td><Link href={`/markets/${h.symbol}`} className="asset-cell"><StockLogo symbol={h.symbol} size={33}/><span><strong>{h.symbol}</strong><small>{h.name}</small></span></Link></td><td className="text-right tnum">{fmtShares(h.shares)}</td><td className="text-right tnum">{fmtMoney(h.price)}</td><td className="text-right tnum holding-value">{fmtMoney(h.value)}</td><td className="text-right tnum"><span className={toneClass(h.pnl)}>{fmtSignedMoney(h.pnl)}</span><small className={`return-percent ${toneClass(h.pnl)}`}>{fmtSignedPct(h.pnlPct)}</small></td><td className="text-right"><span className="weight-cell"><i className="weight-track"><i style={{ width: `${Math.min(100, h.weight * 100)}%` }}/></i><span>{(h.weight * 100).toFixed(1)}%</span></span></td>{!preview && <td className="text-right"><button type="button" className="btn btn-xs" onClick={() => openQuickTrade(h.symbol, "sell")}>Sell <Icon name="arrowUpRight" size={11}/></button></td>}
    </tr>)}</tbody></table></div>
      <div className="mobile-stock-list">{rows.map(h => <article key={h.symbol} className="mobile-position"><div className="flex items-center justify-between gap-3"><Link href={`/markets/${h.symbol}`} className="asset-cell"><StockLogo symbol={h.symbol} size={34}/><span><strong>{h.symbol}</strong><small>{fmtShares(h.shares)} shares · {fmtMoney(h.price)}</small></span></Link><div className="text-right tnum"><strong>{fmtMoney(h.value)}</strong><small className={`return-percent ${toneClass(h.pnl)}`}>{fmtSignedMoney(h.pnl)} ({fmtSignedPct(h.pnlPct)})</small></div></div>{!preview && <button type="button" className="btn btn-xs mt-3" onClick={() => openQuickTrade(h.symbol, "sell")}>Sell shares <Icon name="arrowUpRight" size={12}/></button>}</article>)}</div></> : <><Empty title="No open positions" hint="Explore stocks to make your first practice investment."/><div className="mb-6 text-center"><Link href="/markets" className="btn btn-primary">Explore stocks <Icon name="arrowRight" size={13}/></Link></div></>}
  </section>;
}
