"use client";

import dynamic from "next/dynamic";
import { useSearchParams } from "next/navigation";
import { Suspense, useState, type FormEvent } from "react";
import { useSim } from "@/components/providers";
import { Icon } from "@/components/icons";
import { Empty, PageHeader, PageLoading, Skeleton } from "@/components/ui";
import { FanChart, type FanBand } from "@/components/charts";
import { fmtCompact, fmtMoney, fmtPct } from "@/lib/format";
import { loadPortfolioProjection, loadStockProjection } from "@/lib/client/research";

type ProjectionResult = {
  bands: FanBand[];
  runCount: number;
  startValue: number;
  horizonDays: number;
  latestHistoryDate: string;
  dataSymbols: string[];
  sourceType: string;
  method: string;
  totalContributed: number;
  probProfit: number;
  terminal: { p5: number; p50: number; p95: number; mean: number };
};
type Estimate = ProjectionResult & { title: string; key: string };

const AdvancedLab = dynamic(() => import("@/components/advanced-lab"), { loading: () => <Skeleton className="h-60"/> });
const HORIZONS = [{ value: 63, label: "3 months" }, { value: 252, label: "1 year" }, { value: 756, label: "3 years" }, { value: 1260, label: "5 years" }];

export default function SimulatorPage() { return <Suspense fallback={<PageLoading/>}><FutureSimulator/></Suspense>; }

function futureLabel(day: number) {
  if (!day) return "Today";
  if (day < 21) return `${day}d`;
  if (day < 252) return `${Math.round(day / 21)}m`;
  return `${(day / 252).toFixed(day % 252 === 0 ? 0 : 1)}y`;
}

function FutureSimulator() {
  const query = useSearchParams();
  const { snapshot, loading } = useSim();
  const [target, setTarget] = useState(query.get("symbol") || "portfolio");
  const [amount, setAmount] = useState("");
  const [horizon, setHorizon] = useState(252);
  const [monthly, setMonthly] = useState("0");
  const [running, setRunning] = useState(false);
  const [estimate, setEstimate] = useState<Estimate | null>(null);
  const [error, setError] = useState("");
  const [advanced, setAdvanced] = useState(false);
  const startValue = Number(amount || snapshot?.totals.portfolioValue || 10_000);
  const monthlyValue = Number(monthly || 0);
  const key = `${target}-${startValue}-${horizon}-${monthlyValue}`;

  const calculate = async (event: FormEvent) => {
    event.preventDefault();
    if (!snapshot || running) return;
    if (!Number.isFinite(startValue) || startValue <= 0 || startValue > 5_000_000 || !Number.isFinite(monthlyValue) || monthlyValue < 0 || monthlyValue > 100_000) {
      setError("Use an initial amount from $0.01 to $5,000,000 and a monthly addition up to $100,000.");
      return;
    }
    setRunning(true);
    setError("");
    try {
      const isPortfolio = target === "portfolio";
      const positions = snapshot.holdings
        .filter(h => h.value > 0 && snapshot.totals.portfolioValue > 0)
        .map(h => ({ symbol: h.symbol, weight: h.value / snapshot.totals.portfolioValue }));
      const result = isPortfolio
        ? await loadPortfolioProjection({ startValue, horizonDays: horizon, monthlyContribution: monthlyValue, positions })
        : await loadStockProjection(target, startValue, horizon, monthlyValue);
      const title = isPortfolio ? "your current portfolio mix" : snapshot.tickers.find(t => t.symbol === target)?.name ?? target;
      setEstimate({ ...result as ProjectionResult, title, key });
    } catch (reason) {
      setEstimate(null);
      setError(reason instanceof Error ? reason.message : "We couldn’t calculate this estimate.");
    } finally {
      setRunning(false);
    }
  };

  if (loading && !snapshot) return <PageLoading/>;
  if (!snapshot) return <Empty title="Let’s reconnect before looking ahead." hint="Try again using the message above."/>;
  const selectedHorizon = HORIZONS.find(item => item.value === horizon)?.label ?? "";

  return <><PageHeader title="Give your future a little thought." subtitle="Explore what actual historical price movements could mean for an investment. No changes to your paper account, and no crystal ball."/>
    <div className="page-stack">
      <div className="grid gap-[22px] min-[850px]:grid-cols-[290px_minmax(0,1fr)]">
        <section className="panel p-6"><h2 className="panel-title">A few simple choices.</h2>
          <form className="mt-6 space-y-5" onSubmit={calculate}>
            <div className="field"><label htmlFor="forecast-stock" className="label">What would you like to explore?</label><select id="forecast-stock" value={target} onChange={e => setTarget(e.target.value)} className="select"><option value="portfolio">My current portfolio mix</option>{snapshot.tickers.map(t => <option key={t.symbol} value={t.symbol}>{t.name}</option>)}</select></div>
            <div className="field"><label htmlFor="forecast-amount" className="label">Starting amount ($)</label><input id="forecast-amount" className="input" inputMode="decimal" placeholder={String(Math.round(snapshot.totals.portfolioValue))} value={amount} onChange={e => setAmount(e.target.value.replace(/[^0-9.]/g, ""))}/><p className="hint">Leave empty to use your portfolio value.</p></div>
            <div className="field"><label htmlFor="forecast-horizon" className="label">How far into the future?</label><select id="forecast-horizon" className="select" value={horizon} onChange={e => setHorizon(Number(e.target.value))}>{HORIZONS.map(item => <option key={item.value} value={item.value}>{item.label}</option>)}</select></div>
            <details className="border-t border-[var(--line)] pt-4"><summary className="cursor-pointer text-[11px] text-[var(--muted)]">Add money each month (optional)</summary><div className="field mt-3"><label className="label" htmlFor="monthly-investment">Monthly addition ($)</label><input id="monthly-investment" className="input" inputMode="decimal" value={monthly} onChange={e => setMonthly(e.target.value.replace(/[^0-9.]/g, ""))}/><p className="hint">This is a forecast assumption only. It won’t deposit money into your account.</p></div></details>
            {error && <p role="alert" className="text-xs down">{error}</p>}
            <button type="submit" className="btn btn-primary w-full" disabled={running}>{running ? "Comparing actual history…" : "Show possible futures"}<Icon name="arrowUpRight" size={14}/></button>
          </form>
        </section>

        <section className="panel flex min-h-[420px] flex-col p-6">
          {estimate ? <>
            <div className="flex flex-wrap items-start justify-between gap-3"><div><p className="card-label">A range of possible outcomes · {estimate.title}</p><h2 className="mt-1 text-[17px] font-medium">{HORIZONS.find(item => item.value === estimate.horizonDays)?.label} from now</h2></div><span className="pill">{estimate.runCount.toLocaleString()} simulated futures</span></div>
            <div className="mt-6"><FanChart bands={estimate.bands} labels={estimate.bands.map(b => futureLabel(b.day))} startValue={estimate.startValue} height={220} formatValue={fmtCompact}/></div>
            <div className="mt-5 grid grid-cols-3 gap-3 border-t border-[var(--line)] pt-5">{[{ label: "Lower outcome", value: estimate.terminal.p5 }, { label: "Typical outcome", value: estimate.terminal.p50 }, { label: "Higher outcome", value: estimate.terminal.p95 }].map((item, index) => <div key={item.label}><p className="text-[10px] text-[var(--muted)]">{item.label}</p><p className={`tnum mt-2 text-[17px] font-medium tracking-tight sm:text-[20px] ${index === 1 ? "text-[#54804c]" : ""}`}>{fmtMoney(item.value, 0)}</p></div>)}</div>
            {key !== estimate.key && <p className="hint mt-4 text-[#b29960]">Your choices changed. Select “Show possible futures” to update this estimate.</p>}
            <p className="hint mt-4">Real daily data through {estimate.latestHistoryDate} · {estimate.dataSymbols.join(", ") || "cash only"}</p>
          </> : <div className="flex flex-1 flex-col items-center justify-center px-6 text-center"><span className="mb-5 grid h-[70px] w-[70px] place-items-center rounded-full border border-[#e5eddb] bg-[#f5f8ee] text-[#95ad7c]"><Icon name="flask" size={28}/></span><h2 className="text-xl font-medium tracking-tight">The future isn’t just one number.</h2><p className="hint mt-3 max-w-xs">Choose a stock or your portfolio and we’ll use its actual daily history to explore a range of possible futures.</p><div className="mt-7 flex items-center gap-2 text-[10px] text-[#a0ad92]"><span className="dot bg-[#b1c39e]"/> {selectedHorizon} · 2,000 simulated paths</div></div>}
        </section>
      </div>

      {estimate && <div className="note flex items-start gap-3"><Icon name="info" size={16} className="mt-0.5 shrink-0"/><div><p>{fmtPct(estimate.probProfit, 0)} of model paths ended above {fmtMoney(estimate.totalContributed, 0)} contributed. The displayed range spans approximately the middle 90% of simulated outcomes.</p><p className="mt-1">{estimate.method} Past performance does not predict future results. Cash in a portfolio projection is assumed to earn 0%.</p></div></div>}
      <details className="details"><summary>How does this estimate work?</summary><div className="details-body"><p className="hint">Monte Carlo draws daily return changes from the actual reported stock-price history and repeats the experiment 2,000 times. The shaded area shows the 5th-to-95th percentile range; the middle line is the median path.</p><p className="hint mt-3">A portfolio forecast combines historical daily returns for your current holdings using their current account weights. Future surprise news, changing holdings, trading costs, taxes and dividends may change actual results. This is a learning tool, not a guaranteed prediction.</p></div></details>
      <details className="details" onToggle={event => setAdvanced(event.currentTarget.open)}><summary>More ways to experiment <span className="ml-auto text-[10px] text-[var(--muted)]">Optional</span></summary><div className="details-body">{advanced && <AdvancedLab/>}</div></details>
    </div></>;
}
