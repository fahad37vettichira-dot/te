"use client";

import { useMemo, useState } from "react";
import { FanChart, type FanBand, LineChart } from "@/components/charts";
import { Segmented } from "@/components/ui";
import { Icon } from "./icons";
import { useSim } from "@/components/providers";
import { fmtCompact, fmtMoney } from "@/lib/format";
import { fmtDayShort } from "@/lib/time";
import { loadPortfolioProjection } from "@/lib/client/research";

type PortfolioProjection = {
  bands: FanBand[];
  runCount: number;
  startValue: number;
  horizonDays: number;
  latestHistoryDate: string;
  dataSymbols: string[];
  cashWeight: number;
  sourceType: string;
  method: string;
};

const PROJECTION_HORIZONS = [
  { days: 252, label: "1 year" },
  { days: 756, label: "3 years" },
  { days: 1260, label: "5 years" },
];

function futureLabel(day: number) {
  if (day === 0) return "Today";
  if (day < 21) return `${day}d`;
  if (day < 252) return `${Math.round(day / 21)}m`;
  return `${(day / 252).toFixed(day % 252 === 0 ? 0 : 1)}y`;
}

export function PortfolioChart() {
  const { snapshot } = useSim();
  const [range, setRange] = useState(63);
  const [mode, setMode] = useState<"history" | "future">("history");
  const [horizonDays, setHorizonDays] = useState(252);
  const [projection, setProjection] = useState<PortfolioProjection | null>(null);
  const [projectionKey, setProjectionKey] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  const investments = useMemo(() => (snapshot?.holdings ?? [])
    .filter(h => h.value > 0 && (snapshot?.totals.portfolioValue ?? 0) > 0)
    .map(h => ({ symbol: h.symbol, weight: h.value / (snapshot?.totals.portfolioValue ?? 1) })), [snapshot?.holdings, snapshot?.totals.portfolioValue]);
  if (!snapshot) return null;
  const { totals, equityCurve, market } = snapshot;
  const data = range ? equityCurve.filter(p => p.day >= market.day - range) : equityCurve;
  const curve = data.length ? data : equityCurve.slice(-1);

  const selected = PROJECTION_HORIZONS.find(h => h.days === horizonDays) ?? PROJECTION_HORIZONS[0];
  const currentKey = `${totals.portfolioValue.toFixed(2)}:${investments.map(p => `${p.symbol}-${p.weight.toFixed(5)}`).join(",")}:${horizonDays}`;

  const loadProjection = async () => {
    if (busy) return;
    setMode("future");
    if (projection && projectionKey === currentKey) return;
    if (!investments.length) {
      setError("Add at least one virtual stock holding to project portfolio growth.");
      return;
    }
    setBusy(true);
    setError("");
    try {
      const result = await loadPortfolioProjection({ startValue: totals.portfolioValue, horizonDays, positions: investments });
      setProjection(result as unknown as PortfolioProjection);
      setProjectionKey(currentKey);
    } catch (e) {
      setProjection(null);
      setProjectionKey("");
      setError(e instanceof Error ? e.message : "Couldn’t calculate the portfolio projection.");
    } finally {
      setBusy(false);
    }
  };

  const updateHorizon = (days: number) => {
    setHorizonDays(days);
    setProjection(null);
    setProjectionKey("");
    setError("");
  };

  return <section className="panel performance-panel">
    <div className="card-heading performance-heading"><h2>Portfolio performance</h2>
      {mode === "history" ? <Segmented className="range-switch" options={[{ value: 5, label: "1W" }, { value: 21, label: "1M" }, { value: 63, label: "3M" }, { value: 0, label: "ALL" }]} value={range} onChange={setRange}/> : <Segmented className="range-switch" options={PROJECTION_HORIZONS.map(h => ({ value: h.days, label: `${h.days / 252}Y` }))} value={horizonDays} onChange={updateHorizon}/>}
    </div>
    {mode === "history" ? <>
      <div className="performance-legend"><span><i className="legend-dot"/>Portfolio value</span><span><i className="legend-dash"/>Starting value</span></div>
      <div className="equity-plot"><LineChart series={[{ name: "Portfolio value", values: curve.map(p => p.value), color: "var(--chart-a)", fill: true, width: 2.3 }]} baseline={curve[0]?.value} labels={curve.map(p => fmtDayShort(p.day, market.epoch))} height={200} formatValue={v => fmtMoney(v, 0)} formatTooltip={fmtMoney} showLastValue xTicks={6}/></div>
    </> : <div className="forecast-body">
      <div className="forecast-intro"><span className="legend-dot violet"/>{selected.label} outlook <span className="forecast-separator">·</span> Starting at {fmtMoney(totals.portfolioValue)}</div>
      {busy ? <div className="forecast-empty" aria-live="polite"><i className="loading-ring"/><strong>Calculating possible outcomes…</strong><p>Loading the historical daily returns for your holdings.</p></div> : projection && projectionKey === currentKey ? <><FanChart bands={projection.bands} labels={projection.bands.map(b => futureLabel(b.day))} startValue={projection.startValue} height={164} formatValue={fmtCompact}/><div className="forecast-results">{[{ label: "Lower range", v: projection.bands.at(-1)?.p5 }, { label: "Middle estimate", v: projection.bands.at(-1)?.p50 }, { label: "Upper range", v: projection.bands.at(-1)?.p95 }].map(m => <div key={m.label}><span>{m.label}</span><strong>{fmtMoney(m.v ?? totals.portfolioValue, 0)}</strong></div>)}</div><p className="forecast-disclaimer">{projection.runCount.toLocaleString()} model paths · Historical data through {projection.latestHistoryDate}. Estimates are not guaranteed.</p></> : <div className="forecast-empty"><span className="forecast-icon"><Icon name="sim" size={22}/></span><strong>Explore your future growth</strong><p>{investments.length ? "Model a range of possible outcomes using reported price history. Requires access to the public data feed." : "Buy a practice stock to model how your portfolio could grow."}</p><button type="button" className="btn btn-sm" disabled={!investments.length} onClick={() => void loadProjection()}><Icon name="flask" size={13}/>Build my future growth graph</button></div>}
      {error && <p className="system-warning" role="alert">{error}</p>}
    </div>}
    <div className="chart-footer"><div className="chart-modes" role="group" aria-label="Portfolio chart view"><button type="button" aria-pressed={mode === "history"} onClick={() => { setMode("history"); setError(""); }}><Icon name="markets" size={13}/>Historical</button><button type="button" aria-pressed={mode === "future"} onClick={() => { setMode("future"); setError(""); }}><Icon name="sim" size={13}/>Future growth</button></div><span className="chart-unit">USD</span></div>
  </section>;
}
