import type { SVGProps } from "react";

export type IconName =
  | "dashboard"
  | "markets"
  | "portfolio"
  | "sim"
  | "news"
  | "activity"
  | "wallet"
  | "plus"
  | "arrowUpRight"
  | "arrowDownRight"
  | "star"
  | "starFilled"
  | "clock"
  | "play"
  | "pause"
  | "bolt"
  | "shield"
  | "search"
  | "chevronDown"
  | "chevronRight"
  | "close"
  | "check"
  | "info"
  | "trash"
  | "settings"
  | "brain"
  | "scale"
  | "target"
  | "flask"
  | "download"
  | "upload" | "sun" | "moon" | "arrowRight" | "arrows" | "layers" | "calendar" | "more" | "forward" | "history" | "candles" | "pie" | "book" | "monitor" | "panel" | "return" | "sliders";

const PATHS: Record<IconName, string[]> = {
  sun: ["M16 12a4 4 0 1 1-8 0 4 4 0 0 1 8 0Z", "M12 2v2m0 16v2M2 12h2m16 0h2M5 5l1.5 1.5m11 11L19 19M5 19l1.5-1.5m11-11L19 5"],
  moon: ["M20.7 13.2A8.8 8.8 0 0 1 10.8 3.3a8.9 8.9 0 1 0 9.9 9.9Z"],
  arrowRight: ["M4 12h15m-6-6 6 6-6 6"],
  arrows: ["M3 7h17m-4-4 4 4-4 4M21 17H4m4-4-4 4 4 4"],
  layers: ["m12 3 9 5-9 5-9-5 9-5ZM3 12l9 5 9-5M3 16.5l9 5 9-5"],
  calendar: ["M5 5h14a1 1 0 0 1 1 1v14H4V6a1 1 0 0 1 1-1Z", "M8 3v4m8-4v4M4 10h16"],
  more: ["M4 12h.01M12 12h.01M20 12h.01"],
  forward: ["m3 5 9 7-9 7zM12 5l9 7-9 7z"],
  history: ["M3.5 10a8.5 8.5 0 1 1 0 5", "M3 4v6h6M12 7v5l4 2"],
  candles: ["M6 3v3m0 8v5M4 6h4v8H4zM14 6v4m0 8v3m-2-11h4v8h-4zM20 2v4m0 5v6m-2-11h4v5h-4z"],
  pie: ["M10 3.2a9 9 0 1 0 10.8 10.8H10V3.2Z", "M14 2.5v7.5h7.5A9 9 0 0 0 14 2.5Z"],
  book: ["M12 6c-3-2-6-2-10-1v14c4-1 7-1 10 1 3-2 6-2 10-1V5c-4-1-7-1-10 1Zm0 0v14"],
  monitor: ["M3 4h18v13H3zM8 21h8m-4-4v4"],
  panel: ["M3 4h18v16H3zM9 4v16"],
  return: ["M4 17l6-6 4 3 7-9m-6 0h6v6"],
  sliders: ["M3 6h7m4 0h7M3 12h12m4 0h2M3 18h2m4 0h12M10 3v6m5 0v6M5 15v6"],
  dashboard: ["M3 3h7v7H3z", "M14 3h7v7h-7z", "M14 14h7v7h-7z", "M3 14h7v7H3z"],
  markets: ["M3 17l6-6 4 4 7-7", "M14 8h7v7"],
  portfolio: ["M3 7h18v13H3z", "M8 7V4h8v3", "M3 12h18", "M10 12v2h4v-2"],
  sim: ["M4 20V10", "M10 20V4", "M16 20v-7", "M22 20H2"],
  news: ["M4 5h12v14H4z", "M16 9h4v10h-4", "M7 9h6", "M7 12h6", "M7 15h4"],
  activity: ["M3 12h4l3 8 4-16 3 8h4"],
  wallet: ["M3 7h16a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z", "M3 7V5a2 2 0 0 1 2-2h12", "M17 13h.01"],
  plus: ["M12 5v14", "M5 12h14"],
  arrowUpRight: ["M7 17L17 7", "M8 7h9v9"],
  arrowDownRight: ["M7 7l10 10", "M17 8v9H8"],
  star: ["M12 3.5l2.6 5.3 5.9.9-4.3 4.2 1 5.8-5.2-2.8-5.2 2.8 1-5.8L3.5 9.7l5.9-.9z"],
  starFilled: ["M12 3.5l2.6 5.3 5.9.9-4.3 4.2 1 5.8-5.2-2.8-5.2 2.8 1-5.8L3.5 9.7l5.9-.9z"],
  clock: ["M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18z", "M12 7v5l3 2"],
  play: ["M8 5l11 7-11 7z"],
  pause: ["M8 5h3v14H8z", "M14 5h3v14h-3z"],
  bolt: ["M13 2L4 14h6l-1 8 9-12h-6z"],
  shield: ["M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"],
  search: ["M11 19a8 8 0 1 0 0-16 8 8 0 0 0 0 16z", "M21 21l-4.3-4.3"],
  chevronDown: ["M6 9l6 6 6-6"],
  chevronRight: ["M9 6l6 6-6 6"],
  close: ["M6 6l12 12", "M18 6L6 18"],
  check: ["M4 12l5 5L20 6"],
  info: ["M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18z", "M12 11v6", "M12 7.5h.01"],
  trash: ["M4 7h16", "M9 7V4h6v3", "M6 7l1 13h10l1-13", "M10 11v6", "M14 11v6"],
  settings: ["M12 15.5a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7z", "M19.4 15a1.7 1.7 0 0 0 .3 1.9l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-2.9 1.2 2 2 0 1 1-4 0 1.7 1.7 0 0 0-2.9-1.2l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1A1.7 1.7 0 0 0 3 15a2 2 0 1 1 0-4 1.7 1.7 0 0 0 1.5-2.9l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1A1.7 1.7 0 0 0 10 4a2 2 0 1 1 4 0 1.7 1.7 0 0 0 2.9 1.5l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1A1.7 1.7 0 0 0 21 11a2 2 0 1 1 0 4z"],
  brain: ["M9 3a3 3 0 0 0-3 3 3 3 0 0 0-1 5.8V15a3 3 0 0 0 4 2.8V21", "M15 3a3 3 0 0 1 3 3 3 3 0 0 1 1 5.8V15a3 3 0 0 1-4 2.8V21", "M12 5v14"],
  scale: ["M12 4v16", "M6 8h12", "M6 8l-3 7h6z", "M18 8l-3 7h6z"],
  target: ["M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18z", "M12 16a4 4 0 1 0 0-8 4 4 0 0 0 0 8z", "M12 12h.01"],
  flask: ["M9 3h6", "M10 3v6l-5 9a2 2 0 0 0 1.8 3h10.4A2 2 0 0 0 19 18l-5-9V3", "M7.5 14h9"],
  download: ["M12 4v11", "M7 11l5 5 5-5", "M5 20h14"],
  upload: ["M12 20V9", "M7 13l5-5 5 5", "M5 4h14"],
};

export function Icon({
  name,
  size = 18,
  filled = false,
  ...props
}: { name: IconName; size?: number; filled?: boolean } & Omit<SVGProps<SVGSVGElement>, "name">) {
  const isFilled = filled || name === "starFilled";
  return (
    <svg
      viewBox="0 0 24 24"
      width={size}
      height={size}
      fill={isFilled ? "currentColor" : "none"}
      stroke="currentColor"
      strokeWidth={1.7}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden
      {...props}
    >
      {PATHS[name].map((d, i) => (
        <path key={i} d={d} />
      ))}
    </svg>
  );
}

export function Logo({ size = 32 }: { size?: number }) {
  return <svg width={size} height={size} viewBox="0 0 40 40" className="brand-mark" aria-hidden="true"><rect width="40" height="40" rx="10" fill="var(--brand, #62e5bc)"/><path d="m8 26 6-5v10H8zM17 19l6-5v17h-6zM26 12l6-5v24h-6z" fill="#09281f"/></svg>;
}
