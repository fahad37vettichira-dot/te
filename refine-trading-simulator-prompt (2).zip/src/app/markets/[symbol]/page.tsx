import { UNIVERSE } from "@/lib/universe";
import { StockPageClient } from "./stock-page";

export const dynamicParams = false;

export function generateStaticParams() {
  return UNIVERSE.map(t => ({ symbol: t.symbol }));
}

export default function StockPage() {
  return <StockPageClient />;
}
