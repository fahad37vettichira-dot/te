import {
  annualizedVol,
  bollingerBands,
  clamp,
  computeSignal,
  dailyReturns,
  DAYS_PER_YEAR,
  gaussian,
  hashString,
  maxDrawdown,
  monteCarlo,
  mulberry32,
  periodReturn,
  REGIME_META,
  rsi,
  sharpeRatio,
  sma,
  stepRegime,
  type Regime,
} from "@/lib/engine";
import { NEWS_TEMPLATES, SECTORS, TICKER_BY_SYMBOL, UNIVERSE } from "@/lib/universe";
import { epochForToday } from "@/lib/time";
import type {
  AccountView,
  CurvePoint,
  HoldingView,
  MarketView,
  NewsView,
  OrderView,
  Snapshot,
  SymbolDetail,
  TickerSignalSummary,
  TickerView,
  TransactionView,
} from "@/lib/api-types";

/* ------------------------------------------------------------- state model */

export type TickerState = {
  symbol: string;
  name: string;
  sector: string;
  description: string;
  price: number;
  prevClose: number;
  dayOpen: number;
  dayHigh: number;
  dayLow: number;
  volume: number;
  annualDrift: number;
  annualVol: number;
  beta: number;
  dividendYield: number;
  updatedDay: number;
};

export type Bar = { day: number; open: number; high: number; low: number; close: number; volume: number };
export type HoldingState = { id: number; symbol: string; shares: number; avgCost: number; openedDay: number };
export type TransactionState = {
  id: number;
  day: number;
  kind: string;
  symbol: string | null;
  shares: number;
  price: number;
  amount: number;
  realized: number;
  note: string;
};
export type OrderState = {
  id: number;
  symbol: string;
  side: "buy" | "sell";
  orderType: "limit" | "stop";
  qty: number;
  limitPrice: number;
  status: "open" | "filled" | "cancelled" | "rejected";
  createdDay: number;
  filledDay: number | null;
  fillPrice: number | null;
};
export type NewsState = {
  id: number;
  day: number;
  kind: string;
  headline: string;
  summary: string;
  symbol: string | null;
  sector: string | null;
  sentiment: number;
  impact: number;
};

export type SimState = {
  version: 1;
  nextId: number;
  account: {
    name: string;
    cash: number;
    startingCash: number;
    netDeposits: number;
    realizedPnl: number;
    taxEnabled: boolean;
    taxRate: number;
    longTermTaxRate: number;
    taxLiability: number;
    taxPaid: number;
  };
  market: {
    day: number;
    epoch: string;
    seed: number;
    indexLevel: number;
    prevIndexLevel: number;
    regime: Regime;
    regimeDays: number;
    speed: number;
    lastTickAt: string;
  };
  tickers: TickerState[];
  history: Record<string, Bar[]>;
  indexHistory: Array<{ day: number; level: number }>;
  accountHistory: Array<{ day: number; value: number; cash: number; invested: number }>;
  holdings: HoldingState[];
  transactions: TransactionState[];
  orders: OrderState[];
  news: NewsState[];
  watchlist: string[];
};

export const WARMUP_DAYS = 540;
const MARKET_VOL = 0.17;
const DEFAULT_SEED = 20260214;
const HISTORY_KEEP = 1560;

const round2 = (n: number) => Math.round(n * 100) / 100;
const round4 = (n: number) => Math.round(n * 10000) / 10000;

/* ---------------------------------------------------------------- seeding */

export function createInitialState(): SimState {
  const epoch = epochForToday(WARMUP_DAYS);
  const baseRng = mulberry32(DEFAULT_SEED);
  const marketPath: number[] = [];
  const regimePath: Regime[] = [];
  let regime: Regime = "bull";
  let indexLevel = 100;
  let regimeDays = 0;

  for (let day = 0; day <= WARMUP_DAYS; day++) {
    if (day > 0) {
      const next = stepRegime(regime, baseRng);
      regimeDays = next === regime ? regimeDays + 1 : 1;
      regime = next;
      const meta = REGIME_META[regime];
      const shock = meta.drift / DAYS_PER_YEAR + (MARKET_VOL * meta.volMul * gaussian(baseRng)) / Math.sqrt(DAYS_PER_YEAR);
      indexLevel = indexLevel * (1 + shock);
    }
    regimePath.push(regime);
    marketPath.push(indexLevel);
  }
  const normalizedIndex = marketPath.map(v => round4((v / marketPath[0]) * 100));

  const history: Record<string, Bar[]> = {};
  const tickers: TickerState[] = [];

  for (const def of UNIVERSE) {
    const rng = mulberry32(hashString(`${def.symbol}-${DEFAULT_SEED}`));
    const idioVol = Math.sqrt(Math.max(def.vol ** 2 - (def.beta * MARKET_VOL) ** 2, 0.0025));
    const closes: number[] = [];
    let price = def.price;
    for (let day = 0; day <= WARMUP_DAYS; day++) {
      if (day > 0) {
        const meta = REGIME_META[regimePath[day]];
        const marketReturn = normalizedIndex[day] / normalizedIndex[day - 1] - 1;
        const idio = (idioVol * meta.volMul * gaussian(rng)) / Math.sqrt(DAYS_PER_YEAR);
        const drift = ((1 - def.beta) * def.drift) / DAYS_PER_YEAR;
        price = Math.max(1, price * Math.exp(drift + def.beta * marketReturn + idio));
      }
      closes.push(price);
    }
    const scale = def.price / closes[closes.length - 1];
    const scaled = closes.map(c => round4(c * scale));
    const baseVol = Math.round(2_500_000 + rng() * 24_000_000);
    const bars: Bar[] = [];
    for (let day = 0; day <= WARMUP_DAYS; day++) {
      const c = scaled[day];
      const prev = day > 0 ? scaled[day - 1] : c;
      const o = round4(prev * (1 + (rng() - 0.5) * 0.005));
      const wick = c * def.vol * 0.014 * (0.35 + rng() * 0.85);
      const h = round4(Math.max(o, c) + wick * rng());
      const l = round4(Math.max(0.5, Math.min(o, c) - wick * rng()));
      bars.push({ day, open: o, high: h, low: l, close: c, volume: Math.round(baseVol * (0.65 + rng() * 0.85)) });
    }
    history[def.symbol] = bars;
    const last = bars[bars.length - 1];
    tickers.push({
      symbol: def.symbol,
      name: def.name,
      sector: def.sector,
      description: def.description,
      price: last.close,
      prevClose: scaled[scaled.length - 2],
      dayOpen: last.open,
      dayHigh: last.high,
      dayLow: last.low,
      volume: last.volume,
      annualDrift: def.drift,
      annualVol: def.vol,
      beta: def.beta,
      dividendYield: def.dividendYield,
      updatedDay: WARMUP_DAYS,
    });
  }

  let nextId = 1;
  const starterDay = WARMUP_DAYS - 90;
  const starters = [
    { symbol: "AAPL", shares: 40 },
    { symbol: "NVDA", shares: 60 },
    { symbol: "MSFT", shares: 20 },
    { symbol: "JPM", shares: 35 },
  ];
  const holdings: HoldingState[] = [];
  const transactions: TransactionState[] = [];
  let starterCost = 0;
  for (const item of starters) {
    const entry = history[item.symbol][starterDay]?.close ?? 100;
    const cost = round2(entry * item.shares);
    starterCost += cost;
    holdings.push({ id: nextId++, symbol: item.symbol, shares: item.shares, avgCost: entry, openedDay: starterDay });
    transactions.push({ id: nextId++, day: starterDay, kind: "buy", symbol: item.symbol, shares: item.shares, price: entry, amount: -cost, realized: 0, note: "Starter portfolio allocation · $0 commission" });
  }
  const starterCash = round2(100_000 - starterCost);
  const accountHistory: SimState["accountHistory"] = [];
  for (let day = starterDay; day <= WARMUP_DAYS; day++) {
    const invested = starters.reduce((sum, s) => sum + s.shares * (history[s.symbol][day]?.close ?? 0), 0);
    accountHistory.push({ day, value: round2(starterCash + invested), cash: starterCash, invested: round2(invested) });
  }

  const newsRng = mulberry32(DEFAULT_SEED + 77);
  const news: NewsState[] = [];
  for (let day = WARMUP_DAYS - 40; day <= WARMUP_DAYS; day++) {
    if (newsRng() > 0.55) continue;
    const item = rollNews(newsRng, day, tickers, false);
    if (item) news.push({ id: nextId++, ...item });
  }

  return {
    version: 1,
    nextId,
    account: { name: "Paper Trader", cash: starterCash, startingCash: 100_000, netDeposits: 100_000, realizedPnl: 0, taxEnabled: false, taxRate: 0.24, longTermTaxRate: 0.15, taxLiability: 0, taxPaid: 0 },
    market: { day: WARMUP_DAYS, epoch, seed: DEFAULT_SEED, indexLevel: normalizedIndex[normalizedIndex.length - 1], prevIndexLevel: normalizedIndex[normalizedIndex.length - 2], regime: regimePath[regimePath.length - 1], regimeDays, speed: 0, lastTickAt: new Date().toISOString() },
    tickers,
    history,
    indexHistory: normalizedIndex.map((level, day) => ({ day, level })),
    accountHistory,
    holdings,
    transactions,
    orders: [],
    news: news.slice(-20),
    watchlist: ["AAPL", "NVDA", "TSLA", "JPM", "MSFT", "LLY"],
  };
}

/* ------------------------------------------------------------------- news */

type GeneratedNews = Omit<NewsState, "id">;

function fillTemplate(text: string, values: Record<string, string>): string {
  return text.replace(/\{(\w+)\}/g, (_, key: string) => values[key] ?? key);
}
function rngRange(rng: () => number, [min, max]: [number, number]): number {
  return min + rng() * (max - min);
}

function rollNews(rng: () => number, day: number, tickerRows: Array<{ symbol: string; name: string; sector: string }>, forceMajorEvent: boolean): GeneratedNews | null {
  const roll = rng();
  const marketTemplates = NEWS_TEMPLATES.filter(t => t.scope === "market");
  const sectorTemplates = NEWS_TEMPLATES.filter(t => t.scope === "sector");
  const symbolTemplates = NEWS_TEMPLATES.filter(t => t.scope === "symbol");

  if (forceMajorEvent) {
    const events = NEWS_TEMPLATES.filter(t => t.kind === "event");
    const tpl = events[Math.floor(rng() * events.length)];
    if (tpl.scope === "symbol" && tickerRows.length) {
      const target = tickerRows[Math.floor(rng() * tickerRows.length)];
      const values = { name: target.name, symbol: target.symbol, sector: target.sector };
      return { day, kind: "event", headline: fillTemplate(tpl.headline, values), summary: fillTemplate(tpl.summary, values), symbol: target.symbol, sector: target.sector, sentiment: rngRange(rng, tpl.sentiment), impact: rngRange(rng, tpl.impact) * 1.25 };
    }
    return { day, kind: "event", headline: fillTemplate(tpl.headline, {}), summary: fillTemplate(tpl.summary, {}), symbol: null, sector: null, sentiment: rngRange(rng, tpl.sentiment), impact: rngRange(rng, tpl.impact) * 1.25 };
  }
  if (roll < 0.22) {
    const tpl = marketTemplates[Math.floor(rng() * marketTemplates.length)];
    return { day, kind: tpl.kind, headline: fillTemplate(tpl.headline, {}), summary: fillTemplate(tpl.summary, {}), symbol: null, sector: null, sentiment: rngRange(rng, tpl.sentiment), impact: rngRange(rng, tpl.impact) };
  }
  if (roll < 0.38 && sectorTemplates.length) {
    const tpl = sectorTemplates[Math.floor(rng() * sectorTemplates.length)];
    const pool = tpl.sectors ?? SECTORS.filter(s => s !== "Communication");
    const sector = pool[Math.floor(rng() * pool.length)];
    return { day, kind: "market", headline: fillTemplate(tpl.headline, { sector }), summary: fillTemplate(tpl.summary, { sector }), symbol: null, sector, sentiment: rngRange(rng, tpl.sentiment), impact: rngRange(rng, tpl.impact) };
  }
  if (roll < 0.95 && tickerRows.length) {
    const target = tickerRows[Math.floor(rng() * tickerRows.length)];
    const tpl = symbolTemplates[Math.floor(rng() * symbolTemplates.length)];
    const values = { name: target.name, symbol: target.symbol, sector: target.sector };
    return { day, kind: tpl.kind, headline: fillTemplate(tpl.headline, values), summary: fillTemplate(tpl.summary, values), symbol: target.symbol, sector: target.sector, sentiment: rngRange(rng, tpl.sentiment), impact: rngRange(rng, tpl.impact) };
  }
  return null;
}

/* ---------------------------------------------------------------- helpers */

function recordAccountPoint(state: SimState): void {
  const priceMap = new Map(state.tickers.map(t => [t.symbol, t.price]));
  const invested = state.holdings.reduce((acc, h) => acc + h.shares * (priceMap.get(h.symbol) ?? 0), 0);
  const point = { day: state.market.day, value: round2(state.account.cash + invested), cash: round2(state.account.cash), invested: round2(invested) };
  const existing = state.accountHistory.findIndex(p => p.day === point.day);
  if (existing >= 0) state.accountHistory[existing] = point;
  else state.accountHistory.push(point);
}

function clone<T>(value: T): T {
  return typeof structuredClone === "function" ? structuredClone(value) : (JSON.parse(JSON.stringify(value)) as T);
}

/* ---------------------------------------------------------------- ticking */

export function advanceMarket(input: SimState, requestedDays: number, triggerEvent = false): SimState {
  if (!Number.isFinite(requestedDays) || requestedDays < 1 || requestedDays > 1260) throw new Error("Choose between 1 trading day and 5 years.");
  const days = Math.round(requestedDays);
  const state = clone(input);
  const byTicker = new Map(state.tickers.map(t => [t.symbol, t]));
  const openOrders = state.orders.filter(o => o.status === "open");
  const account = state.account;
  let { day, regime, regimeDays, indexLevel, prevIndexLevel } = state.market;

  const fill = (order: OrderState, fillPrice: number) => {
    if (order.side === "buy") {
      const cost = round2(order.qty * fillPrice);
      if (cost > account.cash + 1e-6) { order.status = "rejected"; return; }
      account.cash = round2(account.cash - cost);
      const holding = state.holdings.find(h => h.symbol === order.symbol);
      if (holding) {
        const newShares = holding.shares + order.qty;
        holding.avgCost = round4((holding.avgCost * holding.shares + cost) / newShares);
        holding.shares = round4(newShares);
      } else {
        state.holdings.push({ id: state.nextId++, symbol: order.symbol, shares: order.qty, avgCost: round4(fillPrice), openedDay: day });
      }
      state.transactions.push({ id: state.nextId++, day, kind: "buy", symbol: order.symbol, shares: order.qty, price: round4(fillPrice), amount: -cost, realized: 0, note: `${order.orderType === "stop" ? "Stop" : "Limit"} order filled` });
    } else {
      const holding = state.holdings.find(h => h.symbol === order.symbol);
      if (!holding || holding.shares + 1e-6 < order.qty) { order.status = "rejected"; return; }
      const proceeds = round2(order.qty * fillPrice);
      const realized = round2(order.qty * (fillPrice - holding.avgCost));
      account.cash = round2(account.cash + proceeds);
      account.realizedPnl = round2(account.realizedPnl + realized);
      const heldDays = Math.max(0, day - holding.openedDay);
      const rate = heldDays >= 252 ? account.longTermTaxRate : account.taxRate;
      if (account.taxEnabled && realized > 0) account.taxLiability = round2(account.taxLiability + realized * rate);
      holding.shares = round4(holding.shares - order.qty);
      if (holding.shares <= 1e-6) state.holdings = state.holdings.filter(h => h.id !== holding.id);
      state.transactions.push({ id: state.nextId++, day, kind: "sell", symbol: order.symbol, shares: order.qty, price: round4(fillPrice), amount: proceeds, realized, note: `${order.orderType === "stop" ? "Stop-loss" : "Limit"} order filled` });
    }
    order.status = "filled";
    order.filledDay = day;
    order.fillPrice = round4(fillPrice);
  };

  const resolve = (order: OrderState, open: number, high: number, low: number) => {
    if (order.status !== "open") return;
    if (order.orderType === "stop") {
      if (order.side === "sell" && low <= order.limitPrice) fill(order, round4(Math.min(order.limitPrice, open)));
      else if (order.side === "buy" && high >= order.limitPrice) fill(order, round4(Math.max(order.limitPrice, open)));
      return;
    }
    if (order.side === "buy" && low <= order.limitPrice) fill(order, round4(Math.min(order.limitPrice, open)));
    else if (order.side === "sell" && high >= order.limitPrice) fill(order, round4(Math.max(order.limitPrice, open)));
  };

  const newsLog: GeneratedNews[] = [];
  for (let step = 0; step < days; step++) {
    day += 1;
    const rng = mulberry32(hashString(`${state.market.seed}-${day}-prices`));
    const nextRegime = stepRegime(regime, rng);
    regimeDays = nextRegime === regime ? regimeDays + 1 : 1;
    regime = nextRegime;
    const meta = REGIME_META[regime];
    const marketShock = meta.drift / DAYS_PER_YEAR + (MARKET_VOL * meta.volMul * gaussian(rng)) / Math.sqrt(DAYS_PER_YEAR);
    prevIndexLevel = indexLevel;
    indexLevel = Math.max(10, indexLevel * Math.exp(marketShock));
    const marketReturn = indexLevel / prevIndexLevel - 1;

    for (const row of state.tickers) {
      row.prevClose = row.price;
      row.dayOpen = round4(row.price * (1 + (rng() - 0.5) * 0.005));
      const idioVol = Math.sqrt(Math.max(row.annualVol ** 2 - (row.beta * MARKET_VOL) ** 2, 0.0025));
      const idio = (idioVol * meta.volMul * gaussian(rng)) / Math.sqrt(DAYS_PER_YEAR);
      const drift = ((1 - row.beta) * row.annualDrift) / DAYS_PER_YEAR;
      row.price = Math.max(1, row.price * Math.exp(drift + row.beta * marketReturn + idio));
    }

    const newsRng = mulberry32(hashString(`${day}-${state.market.seed}-news`));
    const forceNow = triggerEvent && step === days - 1;
    let attempts = forceNow ? 1 : newsRng() < 0.48 ? 1 : 0;
    if (newsRng() < 0.1) attempts += 1;
    const eventsToday: GeneratedNews[] = [];
    for (let n = 0; n < attempts; n++) {
      const item = rollNews(newsRng, day, state.tickers, forceNow && n === 0);
      if (item && !eventsToday.some(e => e.headline === item.headline && e.symbol === item.symbol)) eventsToday.push(item);
    }
    for (const item of eventsToday) {
      const targets = item.symbol ? [byTicker.get(item.symbol)].filter(Boolean) : item.sector ? state.tickers.filter(t => t.sector === item.sector) : state.tickers;
      for (const target of targets) {
        if (!target) continue;
        const scalar = item.symbol ? 1 : item.sector ? 0.85 : target.beta * 0.9;
        target.price = Math.max(1, target.price * (1 + item.impact * scalar));
      }
      if (!item.symbol && !item.sector) indexLevel = Math.max(10, indexLevel * (1 + item.impact));
      newsLog.push(item);
    }

    for (const row of state.tickers) {
      row.price = round4(row.price);
      const wick = row.price * row.annualVol * 0.015 * (0.4 + rng());
      row.dayHigh = round4(Math.max(row.dayOpen, row.price) + wick * rng());
      row.dayLow = round4(Math.max(0.5, Math.min(row.dayOpen, row.price) - wick * rng()));
      row.volume = Math.round((2_500_000 + hashString(row.symbol) % 24_000_000) * (0.65 + rng() * 0.85));
      row.updatedDay = day;
    }

    for (const order of openOrders) {
      const row = byTicker.get(order.symbol);
      if (row) resolve(order, row.dayOpen, row.dayHigh, row.dayLow);
    }

    if (day % 63 === 0 && state.holdings.length) {
      for (const holding of state.holdings) {
        const row = byTicker.get(holding.symbol);
        if (!row || row.dividendYield <= 0) continue;
        const amount = holding.shares * row.price * (row.dividendYield / 4);
        if (amount < 0.01) continue;
        account.cash = round2(account.cash + amount);
        state.transactions.push({ id: state.nextId++, day, kind: "dividend", symbol: holding.symbol, shares: holding.shares, price: round4(row.price), amount: round2(amount), realized: 0, note: `Quarterly dividend · ${(row.dividendYield * 100).toFixed(2)}% yield` });
      }
    }

    for (const row of state.tickers) {
      state.history[row.symbol].push({ day, open: row.dayOpen, high: row.dayHigh, low: row.dayLow, close: row.price, volume: row.volume });
    }
    state.indexHistory.push({ day, level: round4(indexLevel) });
    const invested = state.holdings.reduce((acc, h) => acc + h.shares * (byTicker.get(h.symbol)?.price ?? 0), 0);
    state.accountHistory.push({ day, value: round2(account.cash + invested), cash: round2(account.cash), invested: round2(invested) });
  }

  for (const item of newsLog.sort((a, b) => b.day - a.day || Math.abs(b.impact) - Math.abs(a.impact)).slice(0, 80).reverse()) {
    state.news.push({ id: state.nextId++, ...item });
  }
  state.news = state.news.slice(-400);
  state.transactions = state.transactions.slice(-2000);
  state.market = { ...state.market, day, indexLevel: round4(indexLevel), prevIndexLevel: round4(prevIndexLevel), regime, regimeDays, lastTickAt: new Date().toISOString() };

  const cutoff = day - HISTORY_KEEP;
  for (const symbol of Object.keys(state.history)) state.history[symbol] = state.history[symbol].filter(b => b.day >= cutoff);
  state.accountHistory = state.accountHistory.filter(p => p.day >= cutoff);
  state.indexHistory = state.indexHistory.filter(p => p.day >= cutoff);
  return state;
}

/* ---------------------------------------------------------------- actions */

export type TradeInput = { symbol: string; side: "buy" | "sell"; qty: number; orderType: "market" | "limit" | "stop"; limitPrice?: number };

export function executeTrade(input: SimState, trade: TradeInput): { state: SimState; message: string } {
  const qty = round4(trade.qty);
  if (!Number.isFinite(qty) || qty <= 0) throw new Error("Enter a quantity greater than zero.");
  if (qty > 5_000_000) throw new Error("That order exceeds the simulation maximum.");
  const state = clone(input);
  const account = state.account;
  const ticker = state.tickers.find(t => t.symbol === trade.symbol.toUpperCase());
  if (!ticker) throw new Error("Unknown symbol");
  const day = state.market.day;
  let restingType: "limit" | "stop" | null = null;
  let restingPrice: number | null = null;

  if (trade.orderType === "limit" || trade.orderType === "stop") {
    const target = round4(trade.limitPrice ?? ticker.price);
    if (!Number.isFinite(target) || target <= 0) throw new Error("Enter a valid trigger/limit price.");
    if (round2(target * qty) < 0.01) throw new Error("The smallest virtual order is $0.01.");
    if (target > ticker.price * 1.5 || target < ticker.price * 0.5) throw new Error("Order price must be within ±50% of current market price.");
    const triggersNow = trade.orderType === "limit"
      ? (trade.side === "buy" ? target >= ticker.price : target <= ticker.price)
      : (trade.side === "sell" ? target >= ticker.price : target <= ticker.price);
    if (!triggersNow) {
      if (trade.side === "buy" && target * qty > account.cash) throw new Error("Order notional exceeds available buying power.");
      if (trade.side === "sell") {
        const holding = state.holdings.find(h => h.symbol === ticker.symbol);
        if (!holding || holding.shares + 1e-6 < qty) throw new Error("You do not own enough shares for this sell order.");
      }
      state.orders.push({ id: state.nextId++, symbol: ticker.symbol, side: trade.side, orderType: trade.orderType, qty, limitPrice: target, status: "open", createdDay: day, filledDay: null, fillPrice: null });
      recordAccountPoint(state);
      return { state, message: `${trade.orderType === "stop" ? "Stop" : "Limit"} ${trade.side} placed: ${qty} ${ticker.symbol} @ $${target.toFixed(2)}` };
    }
    restingType = trade.orderType;
    restingPrice = target;
  }

  const price = round4(ticker.price);
  if (round2(qty * price) < 0.01) throw new Error("The smallest virtual trade is $0.01.");
  const pushResting = (side: "buy" | "sell") => {
    if (restingType && restingPrice !== null) state.orders.push({ id: state.nextId++, symbol: ticker.symbol, side, orderType: restingType, qty, limitPrice: restingPrice, status: "filled", createdDay: day, filledDay: day, fillPrice: price });
  };

  if (trade.side === "buy") {
    const cost = round2(qty * price);
    if (cost > account.cash + 0.005) throw new Error("Insufficient buying power for this order.");
    const holding = state.holdings.find(h => h.symbol === ticker.symbol);
    if (holding) {
      const newShares = round4(holding.shares + qty);
      holding.avgCost = round4((holding.avgCost * holding.shares + cost) / newShares);
      holding.shares = newShares;
    } else {
      state.holdings.push({ id: state.nextId++, symbol: ticker.symbol, shares: qty, avgCost: price, openedDay: day });
    }
    account.cash = round2(account.cash - cost);
    state.transactions.push({ id: state.nextId++, day, kind: "buy", symbol: ticker.symbol, shares: qty, price, amount: -cost, realized: 0, note: restingPrice !== null ? "Marketable order filled instantly" : "Market order · $0 commission" });
    pushResting("buy");
    recordAccountPoint(state);
    return { state, message: `Bought ${qty.toLocaleString("en-US", { maximumFractionDigits: 4 })} ${ticker.symbol} at $${price.toFixed(2)}` };
  }

  const holding = state.holdings.find(h => h.symbol === ticker.symbol);
  if (!holding || holding.shares + 1e-6 < qty) throw new Error("You do not own that many shares.");
  const proceeds = round2(qty * price);
  const realized = round2(qty * (price - holding.avgCost));
  const heldDays = Math.max(0, day - holding.openedDay);
  const rate = heldDays >= 252 ? account.longTermTaxRate : account.taxRate;
  const newShares = round4(holding.shares - qty);
  if (newShares <= 1e-6) state.holdings = state.holdings.filter(h => h.id !== holding.id);
  else holding.shares = newShares;
  const taxDelta = account.taxEnabled && realized > 0 ? round2(realized * rate) : 0;
  account.cash = round2(account.cash + proceeds);
  account.realizedPnl = round2(account.realizedPnl + realized);
  account.taxLiability = round2(account.taxLiability + taxDelta);
  state.transactions.push({ id: state.nextId++, day, kind: "sell", symbol: ticker.symbol, shares: qty, price, amount: proceeds, realized, note: taxDelta > 0 ? `Tax simulator reserved $${taxDelta.toFixed(2)} (${heldDays >= 252 ? "long-term" : "short-term"})` : "Market order · $0 commission" });
  pushResting("sell");
  recordAccountPoint(state);
  return { state, message: `Sold ${qty.toLocaleString("en-US", { maximumFractionDigits: 4 })} ${ticker.symbol} at $${price.toFixed(2)} · ${realized >= 0 ? "+" : ""}$${realized.toFixed(2)} realized` };
}

export function cancelOrder(input: SimState, id: number): SimState {
  const state = clone(input);
  const order = state.orders.find(o => o.id === id && o.status === "open");
  if (order) order.status = "cancelled";
  return state;
}

export function adjustCash(input: SimState, cash: { action: "deposit" | "withdraw"; amount: number; settleTax?: boolean }): { state: SimState; message: string } {
  const amount = round2(cash.amount);
  if (!Number.isFinite(amount) || amount <= 0) throw new Error("Enter an amount greater than zero.");
  const state = clone(input);
  const account = state.account;
  const day = state.market.day;
  if (cash.action === "deposit") {
    if (amount > 5_000_000) throw new Error("Single virtual deposits are capped at $5,000,000.");
    account.cash = round2(account.cash + amount);
    account.netDeposits = round2(account.netDeposits + amount);
    state.transactions.push({ id: state.nextId++, day, kind: "deposit", symbol: null, shares: 0, price: 0, amount, realized: 0, note: "Virtual funds added" });
    recordAccountPoint(state);
    return { state, message: `Added $${amount.toLocaleString()} in virtual cash` };
  }
  const taxSettle = cash.settleTax && account.taxEnabled ? round2(account.taxLiability) : 0;
  const total = round2(amount + taxSettle);
  if (total > account.cash + 0.005) throw new Error("Withdrawal exceeds available cash.");
  account.cash = round2(account.cash - total);
  account.netDeposits = round2(account.netDeposits - amount);
  account.taxLiability = round2(account.taxLiability - taxSettle);
  account.taxPaid = round2(account.taxPaid + taxSettle);
  state.transactions.push({ id: state.nextId++, day, kind: "withdraw", symbol: null, shares: 0, price: 0, amount: -amount, realized: 0, note: "Virtual funds withdrawn" });
  if (taxSettle > 0) state.transactions.push({ id: state.nextId++, day, kind: "tax", symbol: null, shares: 0, price: 0, amount: -taxSettle, realized: 0, note: "Simulated capital gains tax settled" });
  recordAccountPoint(state);
  return { state, message: `Withdrew $${amount.toLocaleString()}${taxSettle > 0 ? ` and settled $${taxSettle.toFixed(2)} simulated tax` : ""}` };
}

export function toggleWatch(input: SimState, symbol: string): { state: SimState; watched: boolean } {
  const upper = symbol.toUpperCase();
  if (!TICKER_BY_SYMBOL[upper]) throw new Error("Unknown symbol");
  const state = clone(input);
  const watched = !state.watchlist.includes(upper);
  state.watchlist = watched ? [...state.watchlist, upper] : state.watchlist.filter(s => s !== upper);
  return { state, watched };
}

export function updateSettings(input: SimState, settings: { taxEnabled?: boolean; taxRate?: number; longTermTaxRate?: number; speed?: number }): SimState {
  for (const value of [settings.taxRate, settings.longTermTaxRate]) {
    if (value !== undefined && (!Number.isFinite(value) || value < 0 || value > 0.5)) throw new Error("Tax rates must be between 0% and 50%.");
  }
  if (settings.speed !== undefined && (!Number.isFinite(settings.speed) || settings.speed < 0 || settings.speed > 300)) throw new Error("Choose a valid simulation speed.");
  const state = clone(input);
  if (typeof settings.taxEnabled === "boolean") state.account.taxEnabled = settings.taxEnabled;
  if (typeof settings.taxRate === "number") state.account.taxRate = clamp(settings.taxRate, 0, 0.5);
  if (typeof settings.longTermTaxRate === "number") state.account.longTermTaxRate = clamp(settings.longTermTaxRate, 0, 0.5);
  if (typeof settings.speed === "number") state.market.speed = clamp(settings.speed, 0, 300);
  return state;
}

/* ---------------------------------------------------------------- views */

function marketView(state: SimState): MarketView {
  const m = state.market;
  return {
    day: m.day,
    epoch: m.epoch,
    startDay: WARMUP_DAYS,
    indexLevel: round2(m.indexLevel),
    indexChange: round2(m.indexLevel - m.prevIndexLevel),
    indexChangePct: m.prevIndexLevel ? m.indexLevel / m.prevIndexLevel - 1 : 0,
    regime: m.regime,
    regimeLabel: REGIME_META[m.regime]?.label ?? m.regime,
    regimeBlurb: REGIME_META[m.regime]?.blurb ?? "",
    speed: m.speed,
    lastTickAt: m.lastTickAt,
  };
}

function holdingView(state: SimState, h: HoldingState): HoldingView {
  const t = state.tickers.find(x => x.symbol === h.symbol);
  const price = t?.price ?? 0;
  const value = h.shares * price;
  const heldDays = Math.max(0, state.market.day - h.openedDay);
  return {
    symbol: h.symbol,
    name: t?.name ?? h.symbol,
    sector: t?.sector ?? "—",
    shares: h.shares,
    avgCost: h.avgCost,
    price,
    prevClose: t?.prevClose ?? price,
    changePct: t && t.prevClose ? price / t.prevClose - 1 : 0,
    value,
    cost: h.shares * h.avgCost,
    pnl: value - h.shares * h.avgCost,
    pnlPct: h.avgCost ? price / h.avgCost - 1 : 0,
    dayPnl: t ? h.shares * (price - (h.openedDay >= state.market.day ? h.avgCost : t.prevClose)) : 0,
    weight: 0,
    beta: t?.beta ?? 1,
    openedDay: h.openedDay,
    heldDays,
    isLongTerm: heldDays >= 252,
  };
}

export function buildSnapshot(state: SimState): Snapshot {
  const day = state.market.day;
  const newsRows = [...state.news].sort((a, b) => b.day - a.day || b.id - a.id).slice(0, 50);
  const txRows = [...state.transactions].sort((a, b) => b.id - a.id).slice(0, 100);
  const indexRows = state.indexHistory;
  const closesOf = (symbol: string) => (state.history[symbol] ?? []).filter(b => b.day >= day - 252).map(b => b.close);

  const holdingViews = state.holdings.map(h => holdingView(state, h));
  const investedValue = holdingViews.reduce((a, h) => a + h.value, 0);
  const portfolioValue = state.account.cash + investedValue;
  for (const h of holdingViews) h.weight = portfolioValue > 0 ? h.value / portfolioValue : 0;
  holdingViews.sort((a, b) => b.value - a.value);
  const dayPnl = holdingViews.reduce((a, h) => a + h.dayPnl, 0);
  const prevValue = portfolioValue - dayPnl;
  const totalPnl = portfolioValue - state.account.netDeposits;
  const unrealized = holdingViews.reduce((a, h) => a + h.pnl, 0);

  const deposits = state.transactions.filter(t => t.kind === "deposit").reduce((a, t) => a + t.amount, 0);
  const withdrawals = state.transactions.filter(t => t.kind === "withdraw").reduce((a, t) => a - t.amount, 0);
  const dividends = state.transactions.filter(t => t.kind === "dividend").reduce((a, t) => a + t.amount, 0);
  const account: AccountView = { ...state.account, withdrawals, totalDeposits: state.account.startingCash + deposits, dividends };
  const market = marketView(state);
  const indexCloses = indexRows.map(r => r.level);
  const topSignals: TickerSignalSummary[] = [];

  const tickers: TickerView[] = [...state.tickers].sort((a, b) => a.symbol.localeCompare(b.symbol)).map(t => {
    const closes = closesOf(t.symbol);
    const symNews = newsRows.filter(n => n.symbol === t.symbol);
    const symSent = symNews.length ? symNews.reduce((a, n) => a + n.sentiment, 0) / symNews.length : 0;
    const sig = computeSignal({ symbol: t.symbol, name: t.name, price: t.price, closes: closes.length ? closes : [t.price], marketCloses: indexCloses, beta: t.beta, drift: t.annualDrift, vol: t.annualVol, regime: state.market.regime, sentiment: symSent, newsCount: symNews.length });
    const changePct = t.prevClose ? t.price / t.prevClose - 1 : 0;
    topSignals.push({ symbol: t.symbol, name: t.name, sector: t.sector, price: t.price, changePct, label: sig.label, score: sig.score, confidence: sig.confidence, target: sig.target, stop: sig.stop, expectedReturn: sig.expectedReturn, risk: sig.risk, summary: sig.summary });
    return { symbol: t.symbol, name: t.name, sector: t.sector, price: t.price, prevClose: t.prevClose, change: t.price - t.prevClose, changePct, volume: t.volume, beta: t.beta, vol: t.annualVol, dividendYield: t.dividendYield, spark: closes.slice(-42), watched: state.watchlist.includes(t.symbol), shares: state.holdings.find(h => h.symbol === t.symbol)?.shares ?? 0, signalLabel: sig.label, signalScore: sig.score, targetPrice: sig.target };
  });
  topSignals.sort((a, b) => Math.abs(b.score) - Math.abs(a.score));

  const priceMap = new Map(state.tickers.map(t => [t.symbol, t.price]));
  const orders: OrderView[] = state.orders.filter(o => o.status === "open").sort((a, b) => b.id - a.id).map(o => ({ id: o.id, symbol: o.symbol, side: o.side, orderType: o.orderType, qty: o.qty, limitPrice: o.limitPrice, status: o.status, createdDay: o.createdDay, price: priceMap.get(o.symbol) ?? 0 }));
  const equityCurve: CurvePoint[] = [...state.accountHistory].sort((a, b) => a.day - b.day).map(p => ({ day: p.day, value: p.value }));
  if (equityCurve.length && equityCurve[equityCurve.length - 1].day !== day) equityCurve.push({ day, value: round2(portfolioValue) });

  const sectorMap = new Map<string, { total: number; count: number }>();
  for (const t of tickers) {
    const e = sectorMap.get(t.sector) ?? { total: 0, count: 0 };
    e.total += t.changePct; e.count += 1; sectorMap.set(t.sector, e);
  }
  const sectors = [...sectorMap.entries()].map(([sector, v]) => ({ sector, changePct: v.total / v.count, count: v.count })).sort((a, b) => b.changePct - a.changePct);

  const recentNews = newsRows.filter(n => n.day >= day - 30);
  const sentiment = recentNews.length ? recentNews.reduce((a, n) => a + n.sentiment * (1 + Math.min(Math.abs(n.impact) * 10, 2)), 0) / recentNews.reduce((a, n) => a + (1 + Math.min(Math.abs(n.impact) * 10, 2)), 0) : 0;
  let above = 0, momentumSum = 0, counted = 0;
  for (const t of state.tickers) {
    const closes = closesOf(t.symbol);
    if (closes.length >= 30) {
      if (t.price > closes.reduce((a, b) => a + b, 0) / closes.length) above += 1;
      momentumSum += periodReturn(closes, 20);
      counted += 1;
    }
  }
  const breadth = counted ? above / counted : 0.5;
  const avgMomentum = counted ? momentumSum / counted : 0;
  const regimeBias = state.market.regime === "bull" ? 12 : state.market.regime === "bear" ? -12 : state.market.regime === "crash" ? -20 : -3;
  const outlookScore = clamp((breadth - 0.5) * 110 + avgMomentum * 320 + sentiment * 22 + regimeBias, -100, 100);
  const prediction = monteCarlo({ startValue: state.market.indexLevel, annualDrift: 0.085 + (state.market.regime === "bull" ? 0.03 : state.market.regime === "bear" ? -0.05 : 0), annualVol: indexCloses.length > 30 ? annualizedVol(indexCloses) : MARKET_VOL, beta: 1, marketVol: MARKET_VOL, days: 30, runs: 400, seed: 7 });
  const outlookLabel = outlookScore >= 45 ? "Risk-on" : outlookScore >= 15 ? "Constructive" : outlookScore > -15 ? "Neutral" : outlookScore > -45 ? "Cautious" : "Risk-off";

  return {
    account,
    market,
    holdings: holdingViews,
    totals: { portfolioValue: round2(portfolioValue), investedValue: round2(investedValue), cash: round2(state.account.cash), unrealized: round2(unrealized), realized: round2(state.account.realizedPnl), totalPnl: round2(totalPnl), totalPnlPct: totalPnl / Math.max(account.totalDeposits, 1), dayPnl: round2(dayPnl), dayPnlPct: prevValue ? dayPnl / prevValue : 0, buyingPower: round2(state.account.cash), positions: state.holdings.length },
    tickers,
    topSignals: topSignals.slice(0, 8),
    news: newsRows.map(n => ({ ...n })),
    transactions: txRows.map(t => ({ ...t })),
    orders,
    watchlist: [...state.watchlist],
    equityCurve,
    indexCurve: indexRows.map(r => ({ day: r.day, value: r.level })),
    sectors,
    outlook: {
      score: outlookScore,
      label: outlookLabel,
      confidence: Math.round(clamp(52 + Math.abs(outlookScore) * 0.4, 50, 94)),
      bullets: [
        `${Math.round(breadth * 100)}% of tracked equities trade above their 30-day moving average.`,
        `Median 30-day index projection ${prediction.terminal.p50 >= state.market.indexLevel ? "+" : ""}${((prediction.terminal.p50 / state.market.indexLevel - 1) * 100).toFixed(1)}% (90% band ${((prediction.terminal.p5 / state.market.indexLevel - 1) * 100).toFixed(1)}% to ${((prediction.terminal.p95 / state.market.indexLevel - 1) * 100).toFixed(1)}%).`,
        `Headline flow is ${sentiment > 0.08 ? "net bullish" : sentiment < -0.08 ? "net bearish" : "balanced"} (${sentiment.toFixed(2)} weighted sentiment).`,
        `${market.regimeLabel}: ${market.regimeBlurb}`,
      ],
      prediction30: { low: prediction.terminal.p5 / state.market.indexLevel - 1, median: prediction.terminal.p50 / state.market.indexLevel - 1, high: prediction.terminal.p95 / state.market.indexLevel - 1, probUp: prediction.probProfit },
      breadth,
      sentiment,
      avgMomentum,
    },
  };
}

export function getSymbolDetail(state: SimState, symbol: string): SymbolDetail | null {
  const upper = symbol.toUpperCase();
  const ticker = state.tickers.find(t => t.symbol === upper);
  if (!ticker) return null;
  const bars = state.history[upper] ?? [];
  const closes = bars.map(b => b.close);
  const year = closes.slice(-252);
  const newsRows = state.news.filter(n => n.symbol === upper).sort((a, b) => b.day - a.day).slice(0, 24);
  const sentiment = newsRows.length ? newsRows.reduce((a, n) => a + n.sentiment, 0) / newsRows.length : 0;
  const signal = computeSignal({ symbol: upper, name: ticker.name, price: ticker.price, closes, marketCloses: state.indexHistory.map(r => r.level), beta: ticker.beta, drift: ticker.annualDrift, vol: ticker.annualVol, regime: state.market.regime, sentiment, newsCount: newsRows.length });
  const bb = bollingerBands(closes, 20, 2);
  const holding = state.holdings.find(h => h.symbol === upper);
  const position = holding ? holdingView(state, holding) : null;
  return {
    ticker: {
      symbol: ticker.symbol, name: ticker.name, sector: ticker.sector, description: ticker.description, price: ticker.price, prevClose: ticker.prevClose, change: ticker.price - ticker.prevClose, changePct: ticker.prevClose ? ticker.price / ticker.prevClose - 1 : 0, volume: ticker.volume, beta: ticker.beta, vol: ticker.annualVol, dividendYield: ticker.dividendYield, spark: closes.slice(-42), watched: state.watchlist.includes(upper), shares: holding?.shares ?? 0, signalLabel: signal.label, signalScore: signal.score, targetPrice: signal.target, annualDrift: ticker.annualDrift, annualVol: ticker.annualVol, dayOpen: ticker.dayOpen, dayHigh: ticker.dayHigh, dayLow: ticker.dayLow,
    },
    history: bars.map(b => ({ ...b })),
    indicators: {
      rsi14: rsi(closes, 14), sma20: sma(closes, 20), sma50: sma(closes, 50), sma200: sma(closes, 200), bollingerUpper: bb?.upper ?? null, bollingerLower: bb?.lower ?? null, vol: ticker.annualVol,
      high52: year.length ? Math.max(...year) : ticker.price, low52: year.length ? Math.min(...year) : ticker.price, fromHigh: year.length ? ticker.price / Math.max(...year) - 1 : 0,
      maxDrawdown: maxDrawdown(year.length ? year : closes), sharpe: sharpeRatio(dailyReturns(closes)), beta: ticker.beta, momentum20: periodReturn(closes, 20), momentum60: periodReturn(closes, 60), avgVolume: ticker.volume,
    },
    signal,
    news: newsRows.map(n => ({ ...n })),
    position,
    cash: state.account.cash,
    market: marketView(state),
    sentiment,
  };
}

export function transactionsCsv(state: SimState, dayToISO: (day: number, epoch: string) => string): string {
  const rows = [...state.transactions].sort((a, b) => b.id - a.id);
  const quote = (value: unknown) => `"${String(value ?? "").replace(/"/g, '""')}"`;
  const lines = [["Date", "Type", "Symbol", "Shares", "Price", "Cash flow", "Realized profit/loss", "Note"].map(quote).join(",")];
  for (const t of rows) lines.push([dayToISO(t.day, state.market.epoch), t.kind, t.symbol, t.shares || "", t.price || "", t.amount.toFixed(2), t.realized.toFixed(2), t.note].map(quote).join(","));
  return lines.join("\r\n");
}
