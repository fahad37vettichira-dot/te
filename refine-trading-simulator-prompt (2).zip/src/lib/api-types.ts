import type { AiSignal } from "./engine";

export type AccountView = {
  name: string;
  cash: number;
  startingCash: number;
  netDeposits: number;
  realizedPnl: number;
  taxEnabled: boolean;
  taxRate: number;
  longTermTaxRate: number;
  taxLiability: number;
  taxPaid: number;
  withdrawals: number;
  totalDeposits: number;
  dividends: number;
};

export type MarketView = {
  day: number;
  epoch: string;
  startDay: number;
  indexLevel: number;
  indexChange: number;
  indexChangePct: number;
  regime: string;
  regimeLabel: string;
  regimeBlurb: string;
  speed: number;
  lastTickAt: string;
};

export type HoldingView = {
  symbol: string;
  name: string;
  sector: string;
  shares: number;
  avgCost: number;
  price: number;
  prevClose: number;
  changePct: number;
  value: number;
  cost: number;
  pnl: number;
  pnlPct: number;
  dayPnl: number;
  weight: number;
  beta: number;
  openedDay: number;
  heldDays: number;
  isLongTerm: boolean;
};

export type TotalsView = {
  portfolioValue: number;
  investedValue: number;
  cash: number;
  unrealized: number;
  realized: number;
  totalPnl: number;
  totalPnlPct: number;
  dayPnl: number;
  dayPnlPct: number;
  buyingPower: number;
  positions: number;
};

export type TickerSignalSummary = {
  symbol: string;
  name: string;
  sector: string;
  price: number;
  changePct: number;
  label: AiSignal["label"];
  score: number;
  confidence: number;
  target: number;
  stop: number;
  expectedReturn: number;
  risk: AiSignal["risk"];
  summary: string;
};

export type TickerView = {
  symbol: string;
  name: string;
  sector: string;
  price: number;
  prevClose: number;
  change: number;
  changePct: number;
  volume: number;
  beta: number;
  vol: number;
  dividendYield: number;
  spark: number[];
  watched: boolean;
  shares: number;
  signalLabel: AiSignal["label"];
  signalScore: number;
  targetPrice: number;
};

export type NewsView = {
  id: number;
  day: number;
  kind: string;
  headline: string;
  summary: string;
  symbol: string | null;
  sector: string | null;
  sentiment: number;
  impact: number;
};

export type TransactionView = {
  id: number;
  day: number;
  kind: string;
  symbol: string | null;
  shares: number;
  price: number;
  amount: number;
  realized: number;
  note: string;
};

export type OrderView = {
  id: number;
  symbol: string;
  side: "buy" | "sell";
  orderType: "limit" | "stop";
  qty: number;
  limitPrice: number;
  status: string;
  createdDay: number;
  price: number;
};

export type CurvePoint = { day: number; value: number };

export type OhlcPoint = {
  day: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
};

export type OutlookView = {
  score: number;
  label: string;
  confidence: number;
  bullets: string[];
  prediction30: { low: number; median: number; high: number; probUp: number };
  breadth: number;
  sentiment: number;
  avgMomentum: number;
};

export type Snapshot = {
  account: AccountView;
  market: MarketView;
  holdings: HoldingView[];
  totals: TotalsView;
  tickers: TickerView[];
  topSignals: TickerSignalSummary[];
  news: NewsView[];
  transactions: TransactionView[];
  orders: OrderView[];
  watchlist: string[];
  equityCurve: CurvePoint[];
  indexCurve: CurvePoint[];
  sectors: Array<{ sector: string; changePct: number; count: number }>;
  outlook: OutlookView;
};

export type SymbolDetail = {
  ticker: TickerView & {
    description: string;
    annualDrift: number;
    annualVol: number;
    dayOpen: number;
    dayHigh: number;
    dayLow: number;
  };
  history: OhlcPoint[];
  indicators: {
    rsi14: number | null;
    sma20: number | null;
    sma50: number | null;
    sma200: number | null;
    bollingerUpper: number | null;
    bollingerLower: number | null;
    vol: number;
    high52: number;
    low52: number;
    fromHigh: number;
    maxDrawdown: number;
    sharpe: number;
    beta: number;
    momentum20: number;
    momentum60: number;
    avgVolume: number;
  };
  signal: AiSignal;
  news: NewsView[];
  position: HoldingView | null;
  cash: number;
  market: MarketView;
  sentiment: number;
};
