/** The appearance setting is independent of the paper trading account. */
export type Theme = "dark" | "light";
export const THEME_KEY = "papertrade.appearance.v1";
export const THEME_COLORS = { dark: "#0b0e13", light: "#f5f7f9" } as const;

// Runs in the static document's head, before the application hydrates.
export const initializeAppearance = `(()=>{let t='dark';try{if(localStorage.getItem('${THEME_KEY}')==='light')t='light'}catch{}document.documentElement.dataset.theme=t;let m=document.getElementById('pt-theme-color');if(!m){m=document.createElement('meta');m.id='pt-theme-color';m.name='theme-color';document.head.appendChild(m)}m.content=t==='light'?'${THEME_COLORS.light}':'${THEME_COLORS.dark}'})()`;
