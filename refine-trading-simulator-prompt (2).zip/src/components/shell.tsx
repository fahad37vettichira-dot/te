"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { Suspense, useState, type ReactNode } from "react";
import { useSearchParams } from "next/navigation";
import { ThemeSwitch } from "./theme-switch";
import { Icon, Logo, type IconName } from "@/components/icons";
import { Modal, Pill, Segmented, InfoRow } from "@/components/ui";
import { TradeTicket } from "@/components/widgets";
import { TimeTravelCard } from "@/components/time-travel";
import { useSim } from "@/components/providers";
import { fmtDayMedium } from "@/lib/time";
import { fmtMoney, fmtSignedMoney, toneClass } from "@/lib/format";

const NAV: { href: string; label: string; short: string; icon: IconName }[] = [
  { href: "/", label: "Overview", short: "Home", icon: "dashboard" },
  { href: "/markets", label: "Explore stocks", short: "Stocks", icon: "candles" },
  { href: "/portfolio", label: "My portfolio", short: "Portfolio", icon: "pie" },
  { href: "/activity", label: "Activity & funds", short: "Activity", icon: "history" },
];
const TOOLS: typeof NAV = [
  { href: "/simulations", label: "Future simulator", short: "Simulator", icon: "flask" },
  { href: "/news", label: "Market news", short: "News", icon: "news" },
];

function FundsDialog() {
  const { funds, openCash, closeCash, snapshot, cash, busy } = useSim();
  const [raw, setRaw] = useState("10000");
  const [settle, setSettle] = useState(false);
  const [error, setError] = useState("");
  if (!snapshot || !funds) return null;
  const amount = Number(raw), reserve = settle && snapshot.account.taxEnabled && funds === "withdraw" ? snapshot.account.taxLiability : 0;
  const valid = Number.isFinite(amount) && amount > 0 && (funds === "deposit" ? amount <= 5_000_000 : amount + reserve <= snapshot.account.cash);
  return <Modal open onClose={closeCash} title={funds === "deposit" ? "Add virtual funds" : "Withdraw virtual cash"} subtitle="No bank details. No real transactions. Just practice money."><Segmented value={funds} options={[{ value: "deposit", label: "Add funds" }, { value: "withdraw", label: "Withdraw" }]} onChange={value => { setError(""); openCash(value); }} />
    <form onSubmit={async e => { e.preventDefault(); if (!valid) return; const result = await cash({ action: funds, amount, settleTax: settle }); if (result.ok) closeCash(); else setError(result.message); }} className="mt-5"><div className="flex items-center justify-between text-xs"><label className="label" htmlFor="fund-amount">{funds === "deposit" ? "How much would you like to add?" : "How much would you like to take out?"}</label></div><div className="relative mt-3"><span className="absolute left-4 top-1/2 -translate-y-1/2 text-xl text-[var(--muted)]">$</span><input id="fund-amount" className="input input-money" inputMode="decimal" value={raw} onChange={e => setRaw(e.target.value.replace(/[^0-9.]/g, "").replace(/(\..*)\./g, "$1"))}/></div><div className="mt-3 flex flex-wrap gap-2">{[1000, 10000, 25000].map(n => <button type="button" key={n} className="btn btn-xs" onClick={() => setRaw(String(n))}>{fmtMoney(n, 0)}</button>)}{funds === "withdraw" && <button type="button" className="btn btn-xs" onClick={() => setRaw(String(Math.max(0, Math.floor((snapshot.account.cash - reserve) * 100) / 100)))}>Max</button>}</div>
    {funds === "withdraw" && snapshot.account.taxEnabled && snapshot.account.taxLiability > 0 && <label className="hint mt-5 flex gap-2"><input type="checkbox" checked={settle} onChange={e => setSettle(e.target.checked)}/> Also settle {fmtMoney(snapshot.account.taxLiability)} of simulated tax</label>}
    <div className="mt-5 rounded-xl bg-[var(--panel-2)] px-4 py-2"><InfoRow label="Cash available" value={fmtMoney(snapshot.account.cash)}/><InfoRow label="Cash after" value={fmtMoney(snapshot.account.cash + (funds === "deposit" ? amount || 0 : -(amount || 0) - reserve))}/></div>
    {funds === "withdraw" && <p className="hint mt-4">Your total profit or loss is <span className={toneClass(snapshot.totals.totalPnl)}>{fmtSignedMoney(snapshot.totals.totalPnl)}</span>. Withdrawing cash doesn’t change that result, except for any simulated tax you settle.</p>}
    {(error || (raw && !valid)) && <p className="mt-4 text-xs down" role="alert">{error || (funds === "withdraw" ? "Enter an amount within your available cash." : "Enter an amount between $0.01 and $5,000,000.")}</p>}
    <button className="btn btn-primary mt-5 w-full" disabled={busy || !valid} type="submit">{busy ? "Updating balance…" : funds === "deposit" ? `Add ${fmtMoney(amount || 0)} in virtual cash` : `Withdraw ${fmtMoney(amount || 0)}`}</button></form></Modal>;
}

function QuickTradeDialog() {
  const { snapshot, quickTrade, closeQuickTrade } = useSim();
  if (!quickTrade || !snapshot) return null;
  const ticker = snapshot.tickers.find(t => t.symbol === quickTrade.symbol);
  if (!ticker) return null;
  return <Modal open onClose={closeQuickTrade} title={quickTrade.side === "sell" ? "Make your next move." : "Let’s make a practice investment."} subtitle="A small step toward being a more confident investor."><TradeTicket key={`${ticker.symbol}-${quickTrade.side}`} symbol={ticker.symbol} name={ticker.name} price={ticker.price} cash={snapshot.account.cash} shares={ticker.shares} initialSide={quickTrade.side} onSuccess={closeQuickTrade}/></Modal>;
}

export function SpeedControl() {
  const { snapshot, openTime } = useSim();
  return <button type="button" onClick={openTime} className="date-control" aria-label="Change simulation date and speed" title="Change simulation date and speed"><Icon name="calendar" size={15}/><span className="header-date-label">{snapshot ? fmtDayMedium(snapshot.market.day, snapshot.market.epoch) : "Simulation date"}</span><Icon name="chevronDown" size={11} className="date-caret"/></button>;
}

// Only the navigation needs the query-string state. The static shell remains prerenderable.
function Navigation({ pathname, count }: { pathname: string; count: number }) {
  const params = useSearchParams();
  const watch = pathname.startsWith("/markets") && params.get("view") === "watchlist";
  const entries = [...NAV.slice(0, 3), { href: "/markets?view=watchlist", label: "Watchlist", short: "Watch", icon: "star" as const }, NAV[3]];
  const item = (n: typeof NAV[number]) => {
    const active = n.href.includes("?") ? watch : n.href === "/" ? pathname === "/" : !(n.href === "/markets" && watch) && pathname.startsWith(n.href);
    return <Link key={n.href} href={n.href} className="nav-item" aria-current={active ? "page" : undefined} data-active={active}><Icon name={n.icon} size={18}/><span>{n.label}</span>{n.label === "Watchlist" && <small className="nav-count">{count}</small>}</Link>;
  };
  return <><p className="sidebar-group">Workspace</p><nav aria-label="Workspace" className="nav-links">{entries.map(item)}</nav><div className="nav-section-rule"/><p className="sidebar-group tools-label">Research tools</p><nav aria-label="Research tools" className="nav-links">{TOOLS.map(item)}</nav></>;
}

export function AppShell({ children }: { children: ReactNode }) {
  const pathname = usePathname();
  const { snapshot, error, storageWarning, refresh, openCash, funds, timeOpen, closeTime, toasts, dismissToast, reset, busy } = useSim();
  const [help, setHelp] = useState(false);
  const [more, setMore] = useState(false);
  const [resetConfirm, setResetConfirm] = useState(false);
  const active = (href: string) => href === "/" ? pathname === "/" : pathname.startsWith(href);
  const current = [...NAV, ...TOOLS].find(n => active(n.href));
  const navLink = (item: typeof NAV[number]) => <Link key={item.href} href={item.href} className="nav-item" data-active={active(item.href)} onClick={() => setMore(false)}><Icon name={item.icon} size={18}/><span>{item.label}</span></Link>;
  return <div className="workspace-frame"><a href="#main-content" className="skip-link">Skip to content</a>
    <aside className="app-sidebar">
      <Link href="/" className="app-brand" aria-label="PaperTrade overview"><Logo size={33}/><span>Paper<span className="brand-light">Trade</span></span></Link>
      <Suspense fallback={<nav aria-label="Workspace" className="nav-links">{NAV.map(navLink)}</nav>}><Navigation pathname={pathname} count={snapshot?.watchlist.length || 0}/></Suspense>
      <div className="sidebar-bottom">
        <div className="sandbox-card"><div className="sandbox-title"><span className="status-dot"/>Paper trading mode</div><p>Real practice. Virtual funds.</p><button type="button" onClick={() => setHelp(true)}>How it works <Icon name="arrowRight" size={13}/></button><svg className="sandbox-art" viewBox="0 0 90 52" fill="none" aria-hidden="true"><g stroke="currentColor" strokeWidth="1"><path d="m-5 57 44-27 48 28M5 62l35-22 33 20M-3 47l42-26 57 31M-4 37l43-26 57 32M-3 27 40 2l55 31"/><path d="m-2 59 75-45M12 62l73-44M28 65l67-40M-9 50l67-40"/></g></svg></div>
        <button type="button" className="profile-button" onClick={() => setHelp(true)} aria-label="Paper trader account guide"><span className="trader-avatar">PT<i/></span><span className="profile-copy"><strong>Paper Trader</strong><small>Local workspace</small></span><Icon name="chevronDown" size={14}/></button>
      </div>
    </aside>
    <div className="app-main">
      <header className="app-header">
        <div className="crumb"><Icon name="panel" size={16}/><span>Workspace</span><Icon name="chevronRight" size={12}/><strong>{current?.label || "Stock details"}</strong></div>
        <Link href="/" className="app-brand mobile-brand" aria-label="PaperTrade overview"><Logo size={28}/><span>Paper<span className="brand-light">Trade</span></span></Link>
        <div className="header-actions"><span className="paper-indicator"><span className="status-dot"/>Paper account</span><div className="header-separator"/><SpeedControl/><div className="header-separator date-separator"/><ThemeSwitch/>{pathname !== "/" && <button type="button" className="btn btn-primary nav-funds" onClick={() => openCash("deposit")}><Icon name="plus" size={14}/><span>Add funds</span></button>}</div>
      </header>
      <div className="app-content">{error && <div className="system-warning" role="alert">{error}<button className="btn btn-xs" onClick={() => void refresh()}>Try again</button></div>}{storageWarning && <div className="system-warning" role="status">{storageWarning}</div>}<main id="main-content">{children}</main><footer className="app-footer"><span className="flex items-center gap-2"><Icon name="shield" size={12}/> Educational use only. No real money at risk.</span><span className="flex items-center gap-2"><span className="status-dot small"/> {storageWarning ? "Session-only workspace" : "Saved on this device"}</span></footer></div>
    </div>
    <nav className="mobile-bar" aria-label="Main navigation">{NAV.map(n => <Link key={n.href} href={n.href} data-active={active(n.href)}><Icon name={n.icon} size={18}/>{n.short}</Link>)}<button type="button" data-active={TOOLS.some(t => active(t.href))} onClick={() => setMore(true)}><Icon name="more" size={18}/>More</button></nav>
    <QuickTradeDialog/>{funds && <FundsDialog key={funds}/>}<Modal open={timeOpen} onClose={closeTime} title="Simulation clock" subtitle="Move your simulated market forward and see what happens to your investments."><TimeTravelCard dialog/></Modal>
    <Modal open={more} onClose={() => setMore(false)} title="Research tools"><nav className="space-y-2">{TOOLS.map(navLink)}<button className="nav-item w-full" onClick={() => { setMore(false); setHelp(true); }}><Icon name="info" size={18}/> How it works</button></nav></Modal>
    <Modal open={help} onClose={() => { setHelp(false); setResetConfirm(false); }} title="Investing practice, made simple." subtitle="No bank account or real money required."><div className="space-y-5">{[{ title: "Find a company you know", body: "Go to Explore stocks. Open a company to see its price, or tap Buy to get started.", icon: "search" as const }, { title: "Make a virtual investment", body: "Enter an amount, review the details, and confirm. You can sell shares whenever you like.", icon: "portfolio" as const }, { title: "See what time changes", body: "Skip a day, a month, or up to five years. Fictional news can move prices unexpectedly.", icon: "clock" as const }].map((step, i) => <div key={step.title} className="flex gap-3"><span className="step-num shrink-0">{i + 1}</span><div><h3 className="text-sm font-medium">{step.title}</h3><p className="hint mt-1">{step.body}</p></div></div>)}<div className="note">Your example account starts with $100,000 and four sample investments. The market starts paused. All model suggestions are educational, not financial advice.</div><details className="details"><summary>Need a fresh start?</summary><div className="details-body"><p className="hint">Resetting removes your holdings, trades, cash changes and simulated progress. It restores the original example account.</p>{resetConfirm ? <div className="mt-4 flex gap-2"><button className="btn btn-danger" disabled={busy} onClick={async () => { await reset(); setHelp(false); setResetConfirm(false); }}>Yes, reset my account</button><button className="btn" onClick={() => setResetConfirm(false)}>Cancel</button></div> : <button className="btn mt-4" onClick={() => setResetConfirm(true)}>Reset practice account</button>}</div></details></div></Modal>
    <div className="pointer-events-none fixed bottom-[90px] right-4 left-4 z-[130] flex flex-col items-end gap-2 min-[1001px]:bottom-6" role="status" aria-live="polite">{toasts.map(t => <button type="button" key={t.id} className={`toast pointer-events-auto flex max-w-sm items-start gap-3 rounded-xl border bg-[var(--panel)] px-4 py-3 text-left shadow-lg ${t.tone === "down" ? "border-[var(--down-line)]" : "border-[var(--accent-line)]"}`} onClick={() => dismissToast(t.id)}><span className={`mt-0.5 ${t.tone === "down" ? "down" : "up"}`}><Icon name={t.tone === "up" ? "check" : "info"} size={16}/></span><span className="text-xs leading-relaxed">{t.message}</span></button>)}</div>
  </div>;
}

