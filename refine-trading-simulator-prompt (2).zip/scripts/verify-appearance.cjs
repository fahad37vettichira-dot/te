/* Run against the exported files: TEST_BASE_URL=http://localhost:3000 node scripts/verify-appearance.cjs */
const { chromium, expect } = require('@playwright/test');
const assert = require('node:assert/strict');
const base = process.env.TEST_BASE_URL || 'http://127.0.0.1:3000';
const key = 'papertrade.appearance.v1';

(async () => {
  const browser = await chromium.launch({ headless: true, args: ['--no-sandbox'] });
  const ctx = await browser.newContext({ viewport: { width: 1440, height: 1000 }, reducedMotion: 'reduce' });
  const page = await ctx.newPage();
  const errors = [], api = [];
  ctx.on('page', p => p.on('pageerror', e => errors.push(e.message)));
  page.on('pageerror', e => errors.push(e.message));
  ctx.on('request', r => { if (r.url().includes('/api/')) api.push(r.url()); });
  // Deliberately offline for optional public historical data. Trading and appearance need no feed.
  await ctx.route('https://query1.finance.yahoo.com/**', r => r.abort());
  const account = p => p.evaluate(() => JSON.parse(localStorage.getItem('paper-trade-sim-v1')).account);
  const theme = (p, mode) => expect(p.locator('html')).toHaveAttribute('data-theme', mode);
  const overflow = async p => assert(await p.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1), 'Content exceeds the viewport: ' + p.url());
  try {
    await page.goto(base, { waitUntil: 'networkidle' });
    await expect(page.getByRole('heading', { name: 'Portfolio overview', exact: true })).toBeVisible();
    await theme(page, 'dark');
    const original = await account(page);
    const darkBackground = await page.evaluate(() => getComputedStyle(document.body).backgroundColor);
    assert.equal(darkBackground, 'rgb(11, 14, 19)');
    const lightButton = page.getByRole('button', { name: 'Use light mode', exact: true });
    await lightButton.focus();
    await page.keyboard.press('Enter');
    await theme(page, 'light');
    await expect(lightButton).toHaveAttribute('aria-pressed', 'true');
    assert.equal(await page.evaluate(k => localStorage.getItem(k), key), 'light');
    await page.reload({ waitUntil: 'networkidle' });
    await theme(page, 'light');
    await expect(page.locator('meta[name="theme-color"]')).toHaveAttribute('content', '#f5f7f9');
    const tab = await ctx.newPage(); await tab.goto(base + '/portfolio/', { waitUntil:'networkidle' });
    await theme(tab, 'light');
    await page.getByRole('button', { name: 'Use dark mode', exact: true }).click();
    await theme(tab, 'dark');
    await tab.close();
    await page.getByRole('button', { name: 'Add funds', exact: true }).click();
    await expect(page.getByRole('dialog')).toBeVisible();
    assert.equal(await page.getByRole('dialog').evaluate(el => getComputedStyle(el).backgroundColor), 'rgb(20, 24, 31)');
    await page.keyboard.press('Escape');
    await page.getByRole('button', { name: 'Manage watchlist' }).click();
    await page.getByRole('textbox', { name: 'Find a company' }).fill('AMZN');
    await page.getByRole('button', { name: 'Follow AMZN', exact: true }).click();
    await page.getByRole('button', { name: 'Unfollow AMZN', exact: true }).click();
    await page.getByRole('button', { name: 'Done', exact: true }).click();
    await page.goto(base + '/markets/', { waitUntil:'networkidle' });
    await page.getByRole('navigation', { name: 'Workspace', exact: true }).getByRole('link', { name:/Watchlist/ }).click();
    await expect(page.getByRole('tab', { name:/Your watchlist/ })).toHaveAttribute('aria-selected','true');
    for (const mode of ['light', 'dark']) {
      await page.getByRole('button', { name:`Use ${mode} mode`, exact:true }).click();
      for (const path of ['/', '/markets/', '/markets/AAPL/', '/portfolio/', '/simulations/', '/news/', '/activity/']) {
        await page.goto(base + path, {waitUntil:'networkidle'});
        await expect(page.locator('main h1')).toBeVisible();
        await theme(page, mode); await overflow(page);
        assert.equal(await page.evaluate(() => getComputedStyle(document.documentElement).colorScheme), mode);
      }
      await page.setViewportSize({width:390,height:844});
      await page.goto(base + '/', {waitUntil:'networkidle'});
      await expect(page.getByRole('button', {name:`Use ${mode} mode`, exact:true})).toBeInViewport();
      await page.getByRole('button', {name:'Add funds',exact:true}).click();
      await expect(page.getByRole('dialog')).toBeVisible(); await overflow(page);
      await page.getByRole('button', {name:'Close dialog'}).click();
      await page.getByRole('button', {name:'More',exact:true}).click();
      await page.getByRole('dialog').getByRole('link', {name:'Market news',exact:true}).click();
      await expect(page.getByRole('dialog')).toHaveCount(0); await theme(page,mode); await overflow(page);
      await page.setViewportSize({width:1440,height:1000});
    }
    assert.deepEqual(await account(page), original, 'Appearance must not modify the trading account.');
    assert.deepEqual(api, [], 'No application API requests.');
    assert.deepEqual(errors, [], 'No browser errors.');
    console.log('PASS: dark default, light/dark switches, keyboard access, reload persistence, cross-tab sync, native controls, 7 routes in both themes, mobile dialogs, watchlist navigation and unchanged account data.');
  } finally { await browser.close(); }
})().catch(e => { console.error(e); process.exitCode = 1; });
