import type { RealCandle } from "./realMarket";

export type BacktestStrategyId = "buy-hold" | "dca" | "rsi" | "macd" | "sma" | "supertrend";

export const BACKTEST_STRATEGIES: Array<{ id: BacktestStrategyId; label: string; description: string }> = [
  { id: "buy-hold", label: "Buy & hold", description: "Invest the full budget on the first day and hold." },
  { id: "dca", label: "Monthly DCA", description: "Split the budget into monthly purchases every 21 sessions." },
  { id: "rsi", label: "RSI mean reversion", description: "Enter below RSI 35, exit above RSI 65." },
  { id: "macd", label: "MACD crossover", description: "Enter when MACD crosses above its signal line; exit below." },
  { id: "sma", label: "SMA trend", description: "Enter when price is above SMA20 and SMA20 is above SMA50; exit below SMA20." },
  { id: "supertrend", label: "Supertrend", description: "Enter when price is above the Supertrend line; exit below it." },
];

export type BacktestResult = {
  symbol: string;
  strategy: BacktestStrategyId;
  strategyLabel: string;
  lookback: number;
  budget: number;
  feeBps: number;
  startDate: string;
  endDate: string;
  bars: number;
  finalValue: number;
  totalReturn: number;
  trades: number;
  wins: number;
  losses: number;
  winRate: number | null;
  avgWin: number | null;
  avgLoss: number | null;
  maxDrawdown: number;
  buyHoldFinal: number;
  dcaFinal: number;
  labels: string[];
  strategyEquity: number[];
  buyHoldEquity: number[];
  dcaEquity: number[];
  assumptions: string;
};

const average = (values: number[]) => values.length ? values.reduce((a, b) => a + b, 0) / values.length : 0;

function smaSeries(values: number[], period: number): Array<number | null> {
  return values.map((_, i) => i + 1 >= period ? average(values.slice(i - period + 1, i + 1)) : null);
}

function emaSeries(values: number[], period: number): number[] {
  if (!values.length) return [];
  const alpha = 2 / (period + 1);
  const out = [values[0]];
  for (let i = 1; i < values.length; i++) out.push(alpha * values[i] + (1 - alpha) * out[i - 1]);
  return out;
}

function rsiSeries(closes: number[], period = 14): Array<number | null> {
  const out: Array<number | null> = Array(closes.length).fill(null);
  if (closes.length <= period) return out;
  let gain = 0, loss = 0;
  for (let i = 1; i <= period; i++) {
    const move = closes[i] - closes[i - 1];
    if (move > 0) gain += move; else loss -= move;
  }
  gain /= period; loss /= period;
  const calc = () => loss <= 1e-12 ? (gain <= 1e-12 ? 50 : 100) : 100 - 100 / (1 + gain / loss);
  out[period] = calc();
  for (let i = period + 1; i < closes.length; i++) {
    const move = closes[i] - closes[i - 1];
    gain = (gain * (period - 1) + Math.max(move, 0)) / period;
    loss = (loss * (period - 1) + Math.max(-move, 0)) / period;
    out[i] = calc();
  }
  return out;
}

function atrSeries(bars: RealCandle[], period = 10): Array<number | null> {
  const trs: number[] = [];
  for (let i = 0; i < bars.length; i++) {
    const prevClose = bars[i - 1]?.close ?? bars[i].close;
    trs.push(Math.max(bars[i].high - bars[i].low, Math.abs(bars[i].high - prevClose), Math.abs(bars[i].low - prevClose)));
  }
  const out: Array<number | null> = Array(bars.length).fill(null);
  if (trs.length < period) return out;
  let value = average(trs.slice(0, period));
  out[period - 1] = value;
  for (let i = period; i < trs.length; i++) {
    value = ((period - 1) * value + trs[i]) / period;
    out[i] = value;
  }
  return out;
}

function supertrendSeries(bars: RealCandle[], period = 10, multiplier = 3): Array<{ line: number | null; bullish: boolean }> {
  const atrs = atrSeries(bars, period);
  const out: Array<{ line: number | null; bullish: boolean }> = Array(bars.length).fill(null).map(() => ({ line: null, bullish: false }));
  let finalUpper = 0, finalLower = 0, bullish = true;
  for (let i = period; i < bars.length; i++) {
    const atr = atrs[i] ?? 0;
    const mid = (bars[i].high + bars[i].low) / 2;
    const upper = mid + multiplier * atr, lower = mid - multiplier * atr;
    if (i === period) {
      finalUpper = upper; finalLower = lower; bullish = bars[i].close >= mid;
    } else {
      const priorClose = bars[i - 1].close;
      finalUpper = upper < finalUpper || priorClose > finalUpper ? upper : finalUpper;
      finalLower = lower > finalLower || priorClose < finalLower ? lower : finalLower;
      bullish = bars[i].close > finalUpper ? true : bars[i].close < finalLower ? false : bullish;
    }
    out[i] = { line: bullish ? finalLower : finalUpper, bullish };
  }
  return out;
}

function maxDrawdown(values: number[]): number {
  let peak = values[0] ?? 0, worst = 0;
  for (const value of values) {
    peak = Math.max(peak, value);
    if (peak > 0) worst = Math.min(worst, value / peak - 1);
  }
  return worst;
}

function dcaEquity(bars: RealCandle[], budget: number): number[] {
  const count = Math.floor((bars.length - 1) / 21) + 1;
  const installment = budget / count;
  let cash = budget, shares = 0;
  return bars.map((bar, i) => {
    if (i % 21 === 0) {
      const spend = Math.min(cash, installment);
      shares += spend / bar.adjustedClose;
      cash -= spend;
    }
    return cash + shares * bar.adjustedClose;
  });
}

function buyHoldEquity(bars: RealCandle[], budget: number): number[] {
  const shares = budget / bars[0].adjustedClose;
  return bars.map(bar => shares * bar.adjustedClose);
}

export function backtestStrategy(input: {
  symbol: string;
  history: RealCandle[];
  strategy: BacktestStrategyId;
  lookback: number;
  budget: number;
  feeBps?: number;
}): BacktestResult {
  const { symbol, history, strategy, lookback, budget } = input;
  const feeBps = input.feeBps ?? 10;
  const feeRate = feeBps / 10_000;
  const bars = history.slice(-Math.max(30, Math.min(lookback, history.length)));
  if (bars.length < 30) throw new Error("At least 30 daily prices are needed for a backtest.");
  if (!Number.isFinite(budget) || budget <= 0 || budget > 5_000_000) throw new Error("Choose a budget from $0.01 to $5,000,000.");

  const closes = bars.map(b => b.adjustedClose);
  const buyHold = buyHoldEquity(bars, budget);
  const dca = dcaEquity(bars, budget);
  const labels = bars.map(b => b.date);
  const strategyMeta = BACKTEST_STRATEGIES.find(s => s.id === strategy)!;

  let cash = budget;
  let shares = 0;
  let entryPrice: number | null = null;
  let trades = 0, wins = 0, losses = 0;
  const winAmounts: number[] = [], lossAmounts: number[] = [];
  const equity: number[] = [];

  const rsi = rsiSeries(closes, 14);
  const ema12 = emaSeries(closes, 12), ema26 = emaSeries(closes, 26);
  const macdLine = ema12.map((v, i) => v - ema26[i]);
  const macdSignal = emaSeries(macdLine, 9);
  const sma20 = smaSeries(closes, 20), sma50 = smaSeries(closes, 50);
  const supertrend = supertrendSeries(bars, 10, 3);

  const enter = (price: number) => {
    if (shares > 0 || cash <= 0) return;
    const spend = cash * (1 - feeRate);
    shares = spend / price;
    cash = 0;
    entryPrice = price;
    trades++;
  };
  const exit = (price: number) => {
    if (shares <= 0 || entryPrice === null) return;
    const proceeds = shares * price * (1 - feeRate);
    const pnl = proceeds - shares * entryPrice;
    if (pnl > 0) { wins++; winAmounts.push(pnl); } else if (pnl < 0) { losses++; lossAmounts.push(pnl); }
    cash = proceeds;
    shares = 0;
    entryPrice = null;
  };

  if (strategy === "buy-hold") {
    enter(bars[0].adjustedClose);
  } else if (strategy === "dca") {
    // DCA is reported separately; strategy equity mirrors the DCA curve.
    equity.push(...dca);
    return {
      symbol, strategy, strategyLabel: strategyMeta.label, lookback: bars.length, budget, feeBps,
      startDate: bars[0].date, endDate: bars.at(-1)!.date, bars: bars.length,
      finalValue: dca.at(-1)!, totalReturn: dca.at(-1)! / budget - 1,
      trades: Math.floor((bars.length - 1) / 21) + 1, wins: 0, losses: 0, winRate: null,
      avgWin: null, avgLoss: null, maxDrawdown: maxDrawdown(dca),
      buyHoldFinal: buyHold.at(-1)!, dcaFinal: dca.at(-1)!,
      labels, strategyEquity: dca, buyHoldEquity: buyHold, dcaEquity: dca,
      assumptions: "Monthly purchases every 21 sessions at the adjusted close. No fees in the DCA comparison curve.",
    };
  }

  for (let i = 0; i < bars.length; i++) {
    const price = bars[i].adjustedClose;
    if (strategy === "rsi") {
      const value = rsi[i];
      if (value !== null) {
        if (shares === 0 && value < 35) enter(price);
        else if (shares > 0 && value > 65) exit(price);
      }
    } else if (strategy === "macd") {
      if (i > 0) {
        const bullish = macdLine[i] > macdSignal[i];
        const wasBullish = macdLine[i - 1] > macdSignal[i - 1];
        if (shares === 0 && bullish && !wasBullish) enter(price);
        else if (shares > 0 && !bullish && wasBullish) exit(price);
      }
    } else if (strategy === "sma") {
      const fast = sma20[i], slow = sma50[i];
      if (fast !== null && slow !== null) {
        if (shares === 0 && price > fast && fast > slow) enter(price);
        else if (shares > 0 && price < fast) exit(price);
      }
    } else if (strategy === "supertrend") {
      const st = supertrend[i];
      if (st.line !== null) {
        if (shares === 0 && st.bullish) enter(price);
        else if (shares > 0 && !st.bullish) exit(price);
      }
    }
    equity.push(cash + shares * price);
  }
  if (shares > 0) {
    const price = bars.at(-1)!.adjustedClose;
    const proceeds = shares * price * (1 - feeRate);
    const pnl = proceeds - shares * (entryPrice ?? price);
    if (pnl > 0) { wins++; winAmounts.push(pnl); } else if (pnl < 0) { losses++; lossAmounts.push(pnl); }
    cash = proceeds;
    shares = 0;
    equity[equity.length - 1] = cash;
  }

  const finalValue = equity.at(-1) ?? budget;
  const closed = wins + losses;
  return {
    symbol,
    strategy,
    strategyLabel: strategyMeta.label,
    lookback: bars.length,
    budget,
    feeBps,
    startDate: bars[0].date,
    endDate: bars.at(-1)!.date,
    bars: bars.length,
    finalValue,
    totalReturn: finalValue / budget - 1,
    trades,
    wins,
    losses,
    winRate: closed ? wins / closed : null,
    avgWin: winAmounts.length ? average(winAmounts) : null,
    avgLoss: lossAmounts.length ? average(lossAmounts) : null,
    maxDrawdown: maxDrawdown(equity),
    buyHoldFinal: buyHold.at(-1)!,
    dcaFinal: dca.at(-1)!,
    labels,
    strategyEquity: equity,
    buyHoldEquity: buyHold,
    dcaEquity: dca,
    assumptions: `Signals use data available at each close and execute at that close. ${feeBps} bps fee per trade. No slippage, taxes, dividends beyond adjusted closes, or short selling. Past backtests do not guarantee future results.`,
  };
}
