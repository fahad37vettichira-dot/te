import type { CSSProperties } from "react";
import { symbolColor } from "@/lib/palette";

/** Self-contained stock marks: no remote logo requests in either appearance. */
export function StockLogo({ symbol, size = 36 }: { symbol: string; size?: number }) {
  const tint = symbolColor(symbol);
  const mark = (() => {
    switch (symbol) {
      case "AAPL": return <svg viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M16.5 3.6c.8-1 1.2-2.2 1.1-3.4-1.2.1-2.6.8-3.4 1.8-.7.8-1.3 2.1-1.1 3.3 1.3.1 2.6-.7 3.4-1.7ZM20.7 17.1c-.5 1.2-.8 1.8-1.5 2.9-1 1.5-2.4 3.3-4 3.3-1.5 0-1.9-1-4-1-2 0-2.5 1-4 1-1.6 0-2.9-1.6-3.9-3.1C.7 16.2.2 10.7 2 8.1c1.3-1.9 3.3-3 5.2-3 1.5 0 2.6 1 3.9 1 1.3 0 2.2-1 4-1 1.6 0 3.4.9 4.7 2.3-4 2.2-3.4 7.8.9 9.7Z"/></svg>;
      case "MSFT": return <svg viewBox="0 0 22 22" aria-hidden="true"><path fill="#f25022" d="M0 0h10v10H0z"/><path fill="#7fba00" d="M12 0h10v10H12z"/><path fill="#00a4ef" d="M0 12h10v10H0z"/><path fill="#ffb900" d="M12 12h10v10H12z"/></svg>;
      case "NVDA": return <svg viewBox="0 0 30 24" fill="none" aria-hidden="true"><path fill="currentColor" fillRule="evenodd" d="M11 2h17v20H11v-3c-4-.4-8-3.2-10-7 2.6-4.1 6.1-6.6 10-7V2Zm0 5c-3.1.5-5.4 2.3-7.2 5 1.7 2.7 4.2 4.5 7.2 5v-2.5c-1.7-.4-3.2-1.3-4.2-2.8 1.1-1.5 2.5-2.4 4.2-2.8V7Zm0 2V7c4.4-.9 8.8.7 12.5 5.1-2.8 4-7 6-12.5 5V15c3.7 1.3 7.6.3 10-3-2.7-2.8-6.5-4.2-10-3Zm0 2v3.4c1.8 1.4 5 .6 6-1.8-1.4-1.6-3.5-2.8-6-1.6Z"/></svg>;
      case "TSLA": return <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M2 4.4c6-2.8 14-2.8 20 0l-1 2C15 3.8 9 3.8 3 6.4l-1-2Zm1.8 3.1c5.5-2.4 11.3-2.4 16.7 0l-2.9 2.9c-1.1-1-2.2-1.5-3.9-1.7L12 22 10.2 8.7c-1.6.2-2.9.9-3.9 1.7L3.8 7.5Z"/></svg>;
      case "META": return <svg viewBox="0 0 30 22" fill="none" aria-hidden="true"><path d="M15 12C10-1 5-1 2 13c-2 10 7 8 11-1C20-3 25 0 28 12c3 12-5 11-13 0Z" stroke="currentColor" strokeWidth="3"/></svg>;
      case "AMZN": return <svg viewBox="0 0 26 28" aria-hidden="true"><text x="13" y="21" textAnchor="middle" fill="currentColor" fontFamily="Georgia,serif" fontWeight="bold" fontSize="31">a</text><path d="M3 23q9 6 20-1m-4 0 4-1-.8 3" stroke="#f7ae4a" strokeWidth="1.6" fill="none" strokeLinecap="round"/></svg>;
      case "JPM": return <span className="jpm-mark">JPM</span>;
      case "LLY": return <span className="lly-mark">Lilly</span>;
      case "GOOGL": return <b className="google-mark">G</b>;
      default: return <span className="generic-mark">{symbol.length <= 3 ? symbol : symbol.slice(0, 2)}</span>;
    }
  })();
  return <span className={`stock-icon stock-logo logo-${symbol.toLowerCase()}`} style={{ width: size, height: size, "--stock-color": tint } as CSSProperties} aria-hidden="true">{mark}</span>;
}
