import type { NextConfig } from "next";

const basePath = (process.env.PUBLIC_URL ?? "").replace(/\/+$/, "");

// Fully static build: no server, no database. Output lands in ./out.
const nextConfig: NextConfig = {
  output: "export",
  basePath,
  assetPrefix: basePath,
  trailingSlash: true,
  images: { unoptimized: true },
};

export default nextConfig;
