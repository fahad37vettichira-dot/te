const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
const MONTHS_LONG = [
  "January",
  "February",
  "March",
  "April",
  "May",
  "June",
  "July",
  "August",
  "September",
  "October",
  "November",
  "December",
];
const WEEKDAYS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

/** Simulated trading days advance Monday -> Friday only. */
export function dayToDate(day: number, epoch: string): Date {
  const start = new Date(`${epoch}T00:00:00.000Z`);
  const weeks = Math.floor(day / 5);
  const rem = ((day % 5) + 5) % 5;
  const weekendOffset = start.getUTCDay() + rem > 5 ? 2 : 0;
  start.setUTCDate(start.getUTCDate() + weeks * 7 + rem + weekendOffset);
  return start;
}

export function dayToISO(day: number, epoch: string): string {
  return dayToDate(day, epoch).toISOString().slice(0, 10);
}

export function fmtDayShort(day: number, epoch: string): string {
  const d = dayToDate(day, epoch);
  return `${MONTHS[d.getUTCMonth()]} ${d.getUTCDate()}`;
}

export function fmtDayMedium(day: number, epoch: string): string {
  const d = dayToDate(day, epoch);
  return `${MONTHS[d.getUTCMonth()]} ${d.getUTCDate()}, ${d.getUTCFullYear()}`;
}

export function fmtDayLong(day: number, epoch: string): string {
  const d = dayToDate(day, epoch);
  return `${WEEKDAYS[d.getUTCDay()]}, ${MONTHS_LONG[d.getUTCMonth()]} ${d.getUTCDate()}, ${d.getUTCFullYear()}`;
}

/** Build an epoch such that `day = warmup` lands on (roughly) today. */
export function epochForToday(warmupDays: number): string {
  const today = new Date();
  const start = new Date(Date.UTC(today.getUTCFullYear(), today.getUTCMonth(), today.getUTCDate()));
  const weeks = Math.floor(warmupDays / 5);
  start.setUTCDate(start.getUTCDate() - weeks * 7);
  // walk back to a weekday so the business-day mapping is clean
  while (start.getUTCDay() === 0 || start.getUTCDay() === 6) {
    start.setUTCDate(start.getUTCDate() - 1);
  }
  return start.toISOString().slice(0, 10);
}

export function daysAgoLabel(a: number, b: number, epoch: string): string {
  return `${fmtDayMedium(a, epoch)} → ${fmtDayMedium(b, epoch)}`;
}
